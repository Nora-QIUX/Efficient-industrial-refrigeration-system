import pandas as pd
import numpy as np
import json
import requests
import psycopg2
import mysql.connector
# from timeout_decorator import timeout
# import timeout_decorator
# from timeout_decorator.timeout_decorator import TimeoutError

# pg数据库连接
pgsql_dict = {
    'database': "discovery_000012",
    'username': "tsnyadmin",
    'password': "Tsny2020",
    'host': "pgm-0jl416j2noxs2x83bo.pg.rds.aliyuncs.com", 'port': "5432"
}
conn_000012 = psycopg2.connect(
    database='discovery_000012',
    user=pgsql_dict.get('username'),
    password=pgsql_dict.get('password'),
    host=pgsql_dict.get('host'),
    port="5432")

# mysql数据库连接
mysql_dict = {
    'localhost': "rm-uf6q54n1p7mx87ef61o.mysql.rds.aliyuncs.com",
    'username': "ts_admin",
    'password': "Tsadmin123",
    'database': "discovery_cloud",
}

# 创建时间戳


def get_date(start_time, end_time, range=1):  # 生成自增时间戳
    tmp_range = pd.period_range(start=start_time, end=end_time,
                                freq='{}t'.format(range), )
    tmp_frame = pd.DataFrame()
    tmp_frame['data_time'] = tmp_range
    # tmp_frame['data_time'] = tmp_frame['data_time'].astype('str')
    tmp_frame['data_time'] = tmp_frame['data_time']. \
        apply(
        lambda x: x.strftime("%Y-%m-%d %H:%M:00")).astype('str')
    return tmp_frame

# 获取冷量数据


def get_cold_data(start_time, end_time, system_id):
    url = "http://106.14.227.58:8098/base/get/external"
    payload = json.dumps({
        "property": 2,
        "systemId": system_id,
        "systemName":'local',
        "startTime": start_time,
        "endTime": end_time
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res_dict = json.loads(response.text).get('data')
    return res_dict

# 获取电量


def get_power_data(start_time, end_time, system_id):
    url = "http://106.14.227.58:8098/base/get/external"
    payload = json.dumps({
        "property": 1,
        "systemId": system_id,
        "systemName": 'all',
        "startTime": start_time,
        "endTime": end_time
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res_dict = json.loads(response.text).get('data')
    return res_dict

# 获取流量

def get_flow_data_api(start_time, end_time, system_id, system_name, device_name):
    url = "http://106.14.227.58:8098/base/get/external"
    payload = json.dumps({
        "property": 3,
        "systemId": system_id,
        "systemName": system_name,
        "startTime": start_time,
        "endTime": end_time
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res_dict = json.loads(response.text).get('data')
    flow = res_dict.get('part').get(device_name)
    flow = 0 if flow==None else flow
    return flow

def get_heat_data(start_time, end_time, system_id):
    url = "http://106.14.227.58:8098/base/get/external"
    payload = json.dumps({
        "property": 4,
        "systemId": system_id,
        "systemName": 'dech',
        "startTime": start_time,
        "endTime": end_time
    })
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    res_dict = json.loads(response.text).get('data')
    return res_dict

def up_load_log(log):
    # 连接到 MySQL 服务器
    cnx = mysql.connector.connect(
        user=mysql_dict.get('username'),
        password=mysql_dict.get('password'),
        host=mysql_dict.get('localhost'),
        database=mysql_dict.get('database'))
    # 创建一个MySQL游标对象
    cursor = cnx.cursor()
    # 准备SQL语句
    add_data = ("INSERT INTO algorithm_script_log "
                "(script_start_time, script_success,"
                "script_name,script_owner,script_cd,script_rule,"
                "script_target,script_log,remark) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)")
    # 插入多条数据到数据库
    data = tuple(i for i in log.values.tolist())
    cursor.executemany(add_data, data)
    # 确认数据已经被插入到数据库中
    cnx.commit()
    # 关闭游标和数据库连接
    cursor.close()
    cnx.close()



# 弃用了，跨脚本调用会没办法捕获到异常
# class Cron_basic_class:
#     def __init__(self, script_name, script_owner, script_cd, script_rule,start_time):
#         # 初始化
#         self.log = pd.DataFrame(columns=['script_start_time', 'script_success',
#                                          'script_name', 'script_owner', 'script_cd', 'script_rule',
#                                          'script_target', 'script_log', 'remark'], data=[[np.nan for i in range(9)]])
#         self.log['script_name'] = script_name
#         self.log['script_owner'] = script_owner
#         self.log['script_cd'] = script_cd
#         self.log['script_rule'] = script_rule
#         # start_time = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:00')
#         self.log['script_start_time'] = start_time.strftime('%Y-%m-%d %H:%M:00')
#     def run(self, job):
#         try:
#             log_frame,system_frame = job
#             self.log['script_target'] = json.dumps(log_frame.to_dict(), ensure_ascii=False, separators=(',', ':'))
#             self.log['script_log'] = json.dumps(system_frame.to_dict(), ensure_ascii=False, separators=(',', ':')),
#             # 记录script_target json
#             # 记录script_log json
#             self.log['script_success'] = 1
#             self.log['remark'] = ''
#         except TimeoutError:
#             self.log['script_success'] = 0
#             self.log['remark'] = 'timeout'
#         except Exception as e:
#             self.log['script_success'] = 0
#             self.log['remark'] = 'check'
#         up_load_log(self.log)