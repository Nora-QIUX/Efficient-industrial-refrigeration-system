import requests
class API_class():
    def plot_post(self,data):
        '''
        给模型界面传数据
        :param data:
        :return:
        '''
        url = 'http://47.116.112.115:30600/second/algorithm-models/add'
        headers = {
            'Content-Type': 'application/json'
        }
        # demo_data
        # data = {
        #     "systemId": 174,
        #     "modelId": "3",
        #     "modelDesc": "该模型输入为：{a:1,b:2}",
        #     "modelTrainCycle": "每1小时重新训练",
        #     "modelAdmin": "test",
        #     "modelStatus": 2,
        #     "modelMape": "3.2",
        #     "modelMae": "4.0",
        #     "modelRealPre": '{"xUnit":"kwh","yUnit":"kwh","data":[{"x":1,"y":1},{"x":2,"y":2.1},{"x":0.5,"y":3.7}]} ',
        #     "modelShortTermPre": '{"unit":"kwh","data":[{"x":1,"y":1,"time":"2023-08-21"},{"x":2,"y":2,"time":"2023-08-22"}]}'
        # }
        response = requests.post(url, headers=headers, json=data, verify=False, allow_redirects=True)
        print(response.status_code)
        print(response.text)

    def commond_post(self,data):
        '''
        封装下发的命令
        :param data:
        demo_data
        data = {
            "systemId": 174,
            "command": "command1"
        }
        '''
        url = 'http://47.116.112.115:30600/second/alg/command/create'
        headers = {
            'Content-Type': 'application/json'
        }

        response = requests.post(url, headers=headers, json=data, verify=False, allow_redirects=True)
        print(response.status_code)
        print(response.text)

    def live_data_post(self,data):
        '''
        下发一些实时需要展示的参数
        :param data:
        :return:
        '''
        url = 'http://47.116.112.115:30600/second/alg/live/update'
        headers = {
            'Content-Type': 'application/json'
        }
        # demo_data
        # data ={
        #     "systemId": 174,
        #     "list": [{
        #             "code": "2",
        #             "value": "200"
        #         },{"code": "3","value": "300"}]}
        response = requests.post(url, headers=headers, json=data, verify=False, allow_redirects=True)
        print(response.status_code)
        print(response.text)

    def result_post(self,data):
        '''
        优化结果
        :param data:
        :return:
        '''
        url = 'http://47.116.112.115:30600/second/alg/result/create'
        headers = {
            'Content-Type': 'application/json'
        }
        # demo_data
        # data = {
        #     "systemId": 174,
        #     "list": [
        #         {   "name": "冷却泵耗电",
        #             "algId": "4",
        #             "currentValue": "200",
        #             "optimizationValue": "200",
        #             "energySaved": "200"},
        #         {   "name": "冷却塔耗电",
        #             "algId": "4",
        #             "currentValue": "300",
        #             "optimizationValue": "300",
        #             "energySaved": "300"}]
        #         {   "name": "冷机耗电",
        #             "algId": "4",
        #             "currentValue": "300",
        #             "optimizationValue": "300",
        #             "energySaved": "300"}]
        response = requests.post(url, headers=headers, json=data, verify=False, allow_redirects=True)
        print(response.status_code)
        print(response.text)

    def advise_post(self,data):
        url = 'http://47.116.112.115:30600/second/alg/advise/create'
        headers = {
            'Content-Type': 'application/json'
        }
        # data = {
        #     "systemId": 174,
        #     "list": [
        #         {
        #             "name": "2",
        #             "currentValue": "200",
        #             "optimizationValue": "200",
        #             "toTableName": "200",
        #             "deviceName": "200",
        #             "fieldName": "200"
        #         },
        #         {
        #             "name": "3",
        #             "currentValue": "300",
        #             "optimizationValue": "300",
        #             "toTableName": "300",
        #             "deviceName": "300",
        #             "fieldName": "300"
        #         }
        #     ]
        # }
        response = requests.post(url, headers=headers, json=data, verify=False, allow_redirects=True)
        print(response.status_code)
        print(response.text)

        pass
if __name__ == "__main__":
    a = API_class()
    data = {
        "systemId": 174,
        "list": [
            {   "name": "冷却泵耗电（测试）",
                "algId": "4",
                "currentValue": "200",
                "optimizationValue": "200",
                "energySaved": "200"},
            {   "name": "冷却塔耗电（测试）",
                "algId": "4",
                "currentValue": "300",
                "optimizationValue": "300",
                "energySaved": "300"},
            {   "name": "冷机耗电（测试）",
                "algId": "4",
                "currentValue": "300",
                "optimizationValue": "300",
                "energySaved": "300"}]}
    a.result_post(data)