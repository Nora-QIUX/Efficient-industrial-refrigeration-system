'''

#成都中试线项目 冷却侧模型训练 钱乔睿
20 */8 * * * cd /lib/algorithm/3051_lengquece_opt && source /root/miniconda3/bin/activate Victor_py37 && python -u cron/cron_train_model.py >> /lib/algorithm/log/3051_train_model.log 2>&1

'''


import pandas as pd
import numpy as np
import sys
# sys.path.append('/lib/tools/algorithm/QQR_env')
sys.path.extend(['/lib/algorithm/3051_lengquece_opt'])
from basic_class.chiller_class import Chiller
from basic_class.coolingtower_class import Cooling_tower
from basic_class.pump_class import Decdwp_pump_group
dech01 = Chiller("3051", 'dech01', 1100, 1775, 5, 535.6)
dech02 = Chiller("3051", 'dech02', 1100, 1775, 5, 535.6)
dech03 = Chiller("3051", 'dech03', 1100, 1775, 5, 535.6)
cooling_tower = Cooling_tower('3051', 'dect_all', 3,3)
decdwp_pump = Decdwp_pump_group('3051', 'decdwp_all', 4, 3)
start_time = '2023-03-01 00:00:00'
end_time = (pd.Timestamp.now()).strftime('%Y-%m-%d %H:00:00')
try:
    print('==============start==============')
    dech01.pcond_train(start_time,end_time)
    dech01.pcond_without_train('2023-03-15 00:00:00',end_time)
    dech02.pcond_train(start_time,end_time)
    dech02.pcond_without_train('2023-03-15 00:00:00',end_time)
    dech03.pcond_train(start_time,end_time)
    dech03.pcond_without_train('2023-03-15 00:00:00',end_time)
    dech01.power_train(start_time,end_time)
    dech02.power_train(start_time,end_time)
    dech03.power_train(start_time,end_time)
    cooling_tower.out_temp_fan_on_train(start_time,end_time)
    cooling_tower.out_temp_without_train(start_time,end_time)
    decdwp_pump.flow_instantaneous_train_test('2023-04-01 00:00:00', end_time, num = 2)
    decdwp_pump.flow_instantaneous_train_test('2023-05-01 00:00:00', end_time, num = 3)
    decdwp_pump.flow_instantaneous_train_test('2023-05-01 00:00:00', end_time, num = 4)
    decdwp_pump.flow_instantaneous_without_train('2023-04-01 00:00:00', end_time, num = 2)
    decdwp_pump.flow_instantaneous_without_train('2023-05-01 00:00:00', end_time, num = 3)
    decdwp_pump.flow_instantaneous_without_train('2023-05-01 00:00:00', end_time, num = 4)
    print('==============end==============')
except Exception as e:
    print('==============error==============')
    print(e)