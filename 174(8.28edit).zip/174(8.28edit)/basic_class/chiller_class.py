'''
冷机类
2023年5月9日11:54:30
所有的predict方法需要到数据，入参需要修改，参考冷却塔类
###
共两个模型
####
模型1：power模型
输入：冷机制冷量，冷机蒸发压力，冷机冷凝压力
表名：dech_3051_l1
1.冷机制冷量：流量*（温差）
流量：flow_instantaneous
温差：temp_chw_in temp_chw_out
流量* 温差 * 4.1868 * 1000 / 3600
2.冷机的蒸发压力：p_evaporator
3.冷机的冷凝压力：p_condenser
输出验证：冷机功率（power_active）
表名：dech_3051_l1
#tips
1.每个时间戳下有3个冷机
2.需要对每个冷机分开建模
select flow_instantaneous,temp_chw_in,temp_chw_out,p_evaporator,p_condenser from dech_3051_l1
+ where device_name = 'dech01'
and data_time between a and b
3.可以不用补全时间戳
从单个冷机角度考虑，不用做修复
4.用参数模型建模
# 参考coolingtower power_predict 方法
5.评估结果的方式：
5.1.训练集使用5/1日之前的数据
5.2.验证集选用5/1日之前的数据
5.3.测试集选用5/1日之后的数据，对多个时间戳进行抽样，没问题的话就通过。

模型2：pcond模型
输入：冷却侧总流量(sum)，冷却塔的出塔水温，热量
1.冷却侧总流量：dech_3051_l1
flow_instantaneous_2 按照每个时间戳进行sum，只保留有三条数据的数据
2.冷却塔的出塔水温：decowp_3051_l1
temp2
3.热量：dech_3051_l1
流量：flow_instantaneous_2
温差：temp_cow_out temp_cow_in
流量* 温差 * 4.1868 * 1000 / 3600
输出验证：p_condenser
表名：dech_3051_l1
'''
import os
import sys

from matplotlib import pyplot as plt

sys.path.append('/lib/algorithm/3051_lengquece_opt')

from adtk.detector import QuantileAD, LevelShiftAD
import numpy as np
import pandas as pd
from tools.tools import conn_000012
from scipy.optimize import curve_fit
from sklearn.metrics import mean_absolute_percentage_error as mape_sklearn, mean_absolute_error
from keras.models import Sequential
from keras.callbacks import EarlyStopping
from keras.layers import Input, concatenate, Dense
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import joblib
# import os
# os.chdir('C:/Users/User/PycharmProjects/algorithm-library-tansuo')  # 设置工作目录



class Chiller (object):

    def __init__(self, system_id:str, device_name: str, Cap:float, P_ref:float, Delta_tch_des:float, Vch_des:float):
        """
        Parameters
        ----------
        system_id: 项目编号
        device_name ：冷机编号
        Cap :冷机额定制冷量
        P_ref :冷机额定功率
        Delta_tch_des ：冷机冷冻侧设计进出口温差
        Vch_des ：冷机冷冻侧设计水流量
        Cap:float查得1100
        -------
        """
        #=================一些常数==============================
        self.RT2KW = 3.517
        self.cpw = 4.2
        self.pw = 1000  # 水的密度,kg/m3
        #==================冷机型号=============================
        self.system_id = system_id #补
        self.device_name = device_name
        self.Cop_ref = Cap / P_ref * self.RT2KW  # US RT to kW
        self.P_ref = P_ref
        self.Cap = Cap * self.RT2KW  # USRT to kw
        self.Delta_tch_des = Delta_tch_des  # 蒸发器进出水设计温差
        self.Vch_des = Vch_des * 3.6  # L/s to m3/h
        # 上下四分位数筛选方法，参数设定
        self.quantile_ad = QuantileAD(high=0.9, low=0.1)
        # 根据突变斜率筛选方法，参数设定
        self.level_shift_ad = LevelShiftAD(c=1.0, side='both', window=20)

    #####################################Power_single开始###############################################
    def power_single_get_data(self, start_time, end_time):  # 包含数据清洗步骤
        """
        return: 输出格式如下
        """
        sql_dech = '''
        select data_time, flow_instantaneous, temp_chw_in, temp_chw_out, p_evaporator, p_condenser, power_active
        from dech_{}_l1
        where device_name = '{}'
        and data_time between '{}' and '{}'
        '''.format(self.system_id, self.device_name, start_time, end_time) # "dech01", "2023-02-01 00:00:00", "2023-05-09 23:59:59"

        conn = conn_000012
        df_dech = pd.read_sql(sql_dech, conn)

        # print('11111111111111111111111111111',df_dech)
        # plt.scatter(df_dech['data_time'], df_dech['power_active'], label='1111', color='orange')
        # plt.legend()
        # plt.title('1')
        # plt.show()
        df_dech = df_dech.dropna().reset_index(drop=True)
        df_dech['CL'] = df_dech['flow_instantaneous']*(df_dech['temp_chw_in']-df_dech['temp_chw_out'])*4.1868*1000/3600
        detect_data = pd.DataFrame()
        detect_data.index = df_dech['data_time'].to_list()
        # print(detect_data.index)
        detect_data['power_active'] = df_dech['power_active'].values
        # print(detect_data['power_active'])
        detect_data['flag_1'] = self.level_shift_ad.fit_detect(
            detect_data['power_active'])
        detect_data['flag_2'] = self.quantile_ad.fit_detect(
            detect_data['power_active'])
        detect_data = detect_data.reset_index(drop=False)
        # 这里会自动对齐正确的index
        df_dech = df_dech[
            (detect_data['flag_1'] == False)
                          # &
            # (detect_data['flag_2'] == False)
                    ].reset_index(drop=True)
        # print('2222222222222222222222222222', df_dech)
        # plt.scatter(df_dech['data_time'], df_dech['power_active'], label='22222', color='orange')
        # plt.legend()
        # plt.title('2')
        # plt.show()
        # 计算滚动平均值 先滑窗平均再进行后面的筛选 不会使数据间断 更有说服力
        # window_size = 5
        # df_dech = df_dech.rolling(window_size).mean()
        # df_dech = df_dech.dropna().reset_index(drop=True)

        # 限制 flow_instantaneous < 1000
        df_dech= df_dech[(df_dech['flow_instantaneous'] < 4000) & (df_dech['flow_instantaneous'] > 0)].reset_index(drop=True)
        # print('3333333333333333333333333333', df_dech)
        # plt.scatter(df_dech['data_time'], df_dech['power_active'], label='33333', color='orange')
        # plt.legend()
        # plt.title('3')
        # plt.show()
        # 限制 temp_chw_in < 30
        df_dech = df_dech[df_dech['temp_chw_in'] < 40].reset_index(drop=True)
        # print('4444444444444444444444444444', df_dech)
        # 限制 temp_chw_out < 40
        df_dech = df_dech[df_dech['temp_chw_out'] < 50].reset_index(drop=True)
        # print('5555555555555555555555555555', df_dech)
        # threshold = 2  # 设定一个通常的阈值（比如数据点超过2倍标准差范围之外会被视为异常值)
        # df_dech = df_dech[~(df_dech['temp_chw_out'] > threshold)].reset_index(drop=True)
        # 限制 power_active < 800
        plt.scatter(df_dech['data_time'], df_dech['power_active'], label='power', color='orange')
        plt.legend()
        plt.title('5')
        plt.show()
        df_dech = df_dech[(df_dech['power_active'] < 800) & (df_dech['power_active'] > 10)].reset_index(drop=True)
        # print('66666666666666666666666666666', df_dech)
        # 限制 CL > 0
        df_dech = df_dech[df_dech['CL'] > 0].reset_index(drop=True)
        # print('77777777777777777777777777777', df_dech)


        X = df_dech[["CL", "p_evaporator", "p_condenser"]].values
        Y = df_dech[['power_active']].values

        return X, Y, df_dech

    def power_single_fun(self, X, *params):
        """
        Parameters
        ----------
        X :[Q, Pevap, Pcond]
            Q :冷机的制冷量，kW
            Pevap :冷机的蒸发压力，kPa
            Pcond :冷机的冷凝压力，kPa
        params:[a0, a1, a2]待拟合参数

        Returns
        -------
        W_Ch ：冷机功率函数
        """

        Q = X[0]
        Pevap = X[1]
        Pcond = X[2] #不懂为什么是横着的
        # Q = X['CL']
        # Pevap = X['p_evaporator']
        # Pcond = X['p_condenser']
        a0, a1, a2 = params
        W_Ch = a0 * pow(Q / self.Cap, a1) * pow(Pcond / Pevap, a2)
        return W_Ch

    def power_single_train(self, start_time, end_time): #包含训练集验证集划分工作
        """
        Parameters
        ----------
        X :冷机功率模型输入变量 [Q, Pevap, Pcond]
        Y :冷机功率 W_Ch

        Returns
        popt ：模型系数
        -------
        """
        X, Y, Z = self.power_single_get_data(start_time, end_time) #这里
        if len(X) == 0:
            print('训练时 没有数据通过get_data函数的筛选')
            return None
        # X = X.values
        X1 = X[:,0]
        X2 = X[:,1]
        X3 = X[:,2]
        X = (X1,X2,X3)
        Y = Y.reshape(1, -1)[0]
        func = self.power_single_fun
        p0 = [0.0, 0.0, 0.0]
        try:
            popt, pcov = curve_fit(func, X, Y, p0=p0, maxfev=50000)
        except:
            popt = p0
        # try:
        #     popt, pcov = curve_fit(func, X, Y, p0=p0, maxfev=50000)
        #     # popt, pcov = curve_fit(func, X.T, Y, p0=p0, maxfev=50000)
        # except BaseException:
        #     popt = p0
        # print(popt)
        # 存popt
        np.save('model/' +
                '{}_{}_power_single_params'.format(self.system_id, self.device_name, self.Cap, self.P_ref, \
                                            self.Delta_tch_des, self.Vch_des), popt)

    def power_single_predict(self, X):
        try:
            params = np.load(
                'model/' +
                '{}_{}_power_single_params.npy'.format(
                    self.system_id,
                    self.device_name,
                    self.Cap,
                    self.P_ref,
                    self.Delta_tch_des,
                    self.Vch_des
                    ))
        except Exception as e:
            print(e)
            return None
        if len(X) == 0:
            print('预测时 没有数据通过get_data函数的筛选')
            return None
        X1 = X[:,0]
        X2 = X[:,1]
        X3 = X[:,2]
        X = (X1, X2, X3)
        a0, a1, a2 = params
        W_Ch = np.array(self.power_single_fun(X, a0, a1, a2))
        return W_Ch
    #####################################Power_single结束###############################################

    #####################################Power_double开始###############################################
    def power_double_get_data(self, start_time, end_time):  # 包含数据清洗步骤
        """
        return: 输出格式如下
        """
        sql_dech = '''
        select data_time, flow_instantaneous, temp_chw_in, temp_chw_out
        , (p_evaporator+coalesce (p_evaporator_ckt2,p_evaporator))/2 as p_evaporator
        , (p_condenser+coalesce (p_condenser_ckt2,p_condenser))/2 as p_condenser
        , (power_active+coalesce (power_active_2,0)) as power_active
        from dech_{}_l1
        where device_name = '{}'
        and data_time between '{}' and '{}'
        '''.format(self.system_id, self.device_name, start_time,
                   end_time)  # "dech01", "2023-02-01 00:00:00", "2023-05-09 23:59:59"

        conn = conn_000012
        df_dech = pd.read_sql(sql_dech, conn)

        df_dech = df_dech.dropna().reset_index(drop=True)
        df_dech['CL'] = df_dech['flow_instantaneous'] * (
                    df_dech['temp_chw_in'] - df_dech['temp_chw_out']) * 4.1868 * 1000 / 3600

        detect_data = pd.DataFrame()
        detect_data.index = df_dech['data_time'].to_list()
        # print(detect_data.index)
        detect_data['power_active'] = df_dech['power_active'].values
        # print(detect_data['power_active'])
        detect_data['flag_1'] = self.level_shift_ad.fit_detect(
            detect_data['power_active'])
        detect_data['flag_2'] = self.quantile_ad.fit_detect(
            detect_data['power_active'])
        detect_data = detect_data.reset_index(drop=False)
        # 这里会自动对齐正确的index
        df_dech = df_dech[(detect_data['flag_1'] == False) &
                          (detect_data['flag_2'] == False)
                          ].reset_index(drop=True)

        # 计算滚动平均值 先滑窗平均再进行后面的筛选 不会使数据间断 更有说服力
        # window_size = 5
        # df_dech = df_dech.rolling(window_size).mean()
        # df_dech = df_dech.dropna().reset_index(drop=True)

        # 限制 flow_instantaneous < 1000
        df_dech = df_dech[(df_dech['flow_instantaneous'] < 4000) & (df_dech['flow_instantaneous'] > 0)].reset_index(
            drop=True)
        # 限制 temp_chw_in < 30
        df_dech = df_dech[df_dech['temp_chw_in'] < 40].reset_index(drop=True)
        # 限制 temp_chw_out < 40
        df_dech = df_dech[df_dech['temp_chw_out'] < 50].reset_index(drop=True)
        # threshold = 2  # 设定一个通常的阈值（比如数据点超过2倍标准差范围之外会被视为异常值)
        # df_dech = df_dech[~(df_dech['temp_chw_out'] > threshold)].reset_index(drop=True)
        # 限制 power_active < 2000
        df_dech = df_dech[(df_dech['power_active'] < 2000) & (df_dech['power_active'] > 300)].reset_index(drop=True)
        # 限制 CL > 0
        df_dech = df_dech[df_dech['CL'] > 0].reset_index(drop=True)

        # # 异常值处理一——模型预处理
        # from sklearn.ensemble import IsolationForest
        # clf = IsolationForest(random_state=0).fit(df_dech)
        # df_dech = df_dech[clf.predict(df_dech) == 1]
        # # 异常值处理二——聚类
        # from sklearn.cluster import DBSCAN
        # outlier_detection = DBSCAN(min_samples=2, eps=3)
        # clusters = outlier_detection.fit_predict(df_dech)
        # mask = clusters == -1
        # df_dech = df_dech[~mask]
        # 异常值处理三——IQR
        # Q1 = df_dech['temp_chw_out'].quantile(0.25)
        # Q3 = df_dech['temp_chw_out'].quantile(0.75)
        # IQR = Q3 - Q1
        # df_dech = df_dech[~((df_dech['temp_chw_out'] < (Q1 - 1.5 * IQR)) | (df_dech['temp_chw_out'] > (Q3 + 1.5 * IQR)))]

        X = df_dech[["CL", "p_evaporator", "p_condenser"]].values
        Y = df_dech[['power_active']].values

        return X, Y, df_dech

    def power_double_fun(self, X, *params):
        """
        Parameters
        ----------
        X :[Q, Pevap, Pcond]
            Q :冷机的制冷量，kW
            Pevap :冷机的蒸发压力，kPa
            Pcond :冷机的冷凝压力，kPa
        params:[a0, a1, a2]待拟合参数

        Returns
        -------
        W_Ch ：冷机功率函数
        """

        Q = X[0]
        Pevap = X[1]
        Pcond = X[2]  # 不懂为什么是横着的
        # Q = X['CL']
        # Pevap = X['p_evaporator']
        # Pcond = X['p_condenser']
        a0, a1, a2 = params
        W_Ch = a0 * pow(Q / self.Cap, a1) * pow(Pcond / Pevap, a2)
        return W_Ch

    def power_double_train(self, start_time, end_time):  # 包含训练集验证集划分工作
        """
        Parameters
        ----------
        X :冷机功率模型输入变量 [Q, Pevap, Pcond]
        Y :冷机功率 W_Ch

        Returns
        popt ：模型系数
        -------
        """
        X, Y, Z = self.power_double_get_data(start_time, end_time)  # 这里
        if len(X) == 0:
            print('训练时 没有数据通过get_data函数的筛选')
            return None
        # X = X.values
        X1 = X[:, 0]
        X2 = X[:, 1]
        X3 = X[:, 2]
        X = (X1, X2, X3)
        Y = Y.reshape(1, -1)[0]
        func = self.power_double_fun
        p0 = [0.0, 0.0, 0.0]
        try:
            popt, pcov = curve_fit(func, X, Y, p0=p0, maxfev=50000)
        except:
            popt = p0
        # try:
        #     popt, pcov = curve_fit(func, X, Y, p0=p0, maxfev=50000)
        #     # popt, pcov = curve_fit(func, X.T, Y, p0=p0, maxfev=50000)
        # except BaseException:
        #     popt = p0
        # print(popt)
        # 存popt
        np.save('model/' +
                '{}_{}_power_double_params'.format(self.system_id, self.device_name, self.Cap, self.P_ref, \
                                                   self.Delta_tch_des, self.Vch_des), popt)

    def power_double_predict(self, X):
        params = np.load(
            'model/' +
            '{}_{}_power_double_params.npy'.format(
                self.system_id,
                self.device_name,
                self.Cap,
                self.P_ref,
                self.Delta_tch_des,
                self.Vch_des
            ))
        if len(X) == 0:
            print('预测时 没有数据通过get_data函数的筛选')
            return None
        X1 = X[:, 0]
        X2 = X[:, 1]
        X3 = X[:, 2]
        X = (X1, X2, X3)
        a0, a1, a2 = params
        W_Ch = np.array(self.power_double_fun(X, a0, a1, a2))
        return W_Ch
    #####################################Power_double结束###############################################


    #####################################Pcond部分开始###################################################
    '''
    模型2：pcond模型
    输入：冷却侧总流量(sum)，冷却塔的出塔水温，热量
    1.冷却侧总流量：dech_3051_l1
    flow_instantaneous_2 按照每个时间戳进行sum，只保留有三条数据的数据
    2.冷却塔的出塔水温：decowp_3051_l1
    temp2 只有decowp01这一种device_name的值
    3.热量：dech_3051_l1
    流量：flow_instantaneous_2
    温差：temp_cow_out temp_cow_in
    流量* 温差 * 4.1868 * 1000 / 3600
    输出验证：p_condenser
    表名：dech_3051_l1
    '''
    def pcond_get_data(self, start_time, end_time):  # 包含数据清洗步骤

        sql_decowp = '''
        select data_time, temp_2
        from decowp_{}_l1
        where data_time between '{}' and '{}'
        '''.format(self.system_id, start_time, end_time)  # "2023-02-01 00:00:00", "2023-05-09 23:59:59"

        sql_dech = '''
        select data_time, 
        flow_instantaneous_2, 
        temp_cow_in, temp_cow_out, p_condenser
        from dech_{}_l1
        where device_name = '{}'
        and data_time between '{}' and '{}'
        '''.format(self.system_id, self.device_name, start_time, end_time)  # "dech01", "2023-02-01 00:00:00", "2023-05-09 23:59:59"

        sql_dech_all = '''
        select data_time, flow_instantaneous_2
        from dech_{}_l1
        where data_time between '{}' and '{}'
        '''.format(self.system_id, start_time, end_time)  # "2023-02-01 00:00:00", "2023-05-09 23:59:59"

        conn = conn_000012
        df_decowp = pd.read_sql(sql_decowp, conn)
        df_decowp = df_decowp.dropna().reset_index(drop=True)
        df_dech = pd.read_sql(sql_dech, conn)
        df_dech = df_dech.dropna().reset_index(drop=True)
        df_dech_all = pd.read_sql(sql_dech_all, conn)
        df_dech_all = df_dech_all.dropna().reset_index(drop=True)

        df_dech['Heat'] = df_dech['flow_instantaneous_2'] * (df_dech['temp_cow_out'] - df_dech['temp_cow_in']) * 4.1868 * 1000 / 3600
        ch_co_merged = pd.merge(df_dech, df_decowp, on='data_time', how='inner')

        df_dech_all_filtered = df_dech_all.groupby('data_time').filter(lambda x: len(x) == 10)
        df_dech_all_sum = df_dech_all_filtered.groupby('data_time')['flow_instantaneous_2'].sum().reset_index()
        df_dech_all_sum = df_dech_all_sum.rename(columns={'flow_instantaneous_2': 'flow_ins2_sum'})
        ch_co_sum_merged = pd.merge(ch_co_merged, df_dech_all_sum, on='data_time', how='inner')
        ch_co_sum_merged = ch_co_sum_merged[
            (ch_co_sum_merged['p_condenser']>80)
        ].reset_index(drop = True)
        # detect_data = pd.DataFrame()
        # detect_data.index = ch_co_sum_merged['data_time']
        # detect_data['p_condenser'] = \
        #     ch_co_sum_merged['p_condenser'].values
        # detect_data['flag_1'] = self.level_shift_ad.fit_detect(
        #     detect_data['p_condenser'])
        # detect_data['flag_2'] = self.quantile_ad.fit_detect(
        #     detect_data['p_condenser'])
        # detect_data = detect_data.reset_index(drop=False)
        # # 这里会自动对齐正确的index
        # ch_co_sum_merged = ch_co_sum_merged[(detect_data['flag_1'] == False) &
        #             (detect_data['flag_2'] == False)
        #             ].reset_index(drop=True)
        # Heat > 1000
        # ch_co_sum_merged = ch_co_sum_merged[ch_co_sum_merged['Heat'] > 100].reset_index(drop=True)
        # flow_instantaneous_2 > 0
        # ch_co_sum_merged = ch_co_sum_merged[ch_co_sum_merged['flow_instantaneous_2'] > 0].reset_index(drop=True)


        X = ch_co_sum_merged[["Heat", "flow_instantaneous_2", "temp_2"]].values
        Y = ch_co_sum_merged[["p_condenser"]].values

        return X, Y, ch_co_sum_merged

    #     '''
    #     处理神经网络的输入 目标样式：
    #     X_train: [freq, temp_cow_in, Q_cond]
    #     y_train: [p_condenser]
    #     因为输入数据有三个特征值，所以取二维数组n*3 作为输入
    #     对应的，取n个标量 作为输出
    #     神经网络需要归一化
    #     树模型不需要归一化
    #     '''
    #     X1 = np.random.normal(loc=40, scale=2, size=100)
    #     X2 = np.random.normal(loc=1600, scale=3, size=100)
    #     X3 = np.random.normal(loc=22, scale=4, size=100)
    #     X = (X1, X2, X3)
    #     X = np.column_stack(X)
    #     # Y = np.random.rand(100)
    #     Y = np.random.normal(loc=5100, scale=4, size=100)
    #     return X, Y
    #
    def pcond_train(self, start_time, end_time):
        """
        训练Pcond的神经网络模型(黑箱模型)
        Parameters
        ----------
            # freq：冷却水泵运行频率，Hz,改成了冷却水流量
            temp_ct_out:冷却塔出口水温
            Q_cond_list：各台冷机的冷凝器换热量[Q_cond_1,Q_cond_2,...,Q_cond_N]
        X_train: [freq, temp_cow_in, Q_cond]
        y_train: [p_condenser]

        Returns
        -------
        """
        X, Y, Z = self.pcond_get_data(start_time, end_time)
        # X = X.values
        # Y = Y.values
        # 分割数据集
        train_X, test_X, train_y, test_y = train_test_split(X, Y,shuffle=True)
        # train_X, eval_X, train_y, eval_y = train_test_split(X, Y)
        # 制作对应的X，y的scaler
        pcond_scaler_X = MinMaxScaler()
        pcond_scaler_y = MinMaxScaler()
        # 用训练数据fitscaler，如果用全量数据会导致数据泄露
        pcond_scaler_X.fit(train_X)
        pcond_scaler_y.fit(train_y)
        # 保存scaler
        sc_X = pcond_scaler_X
        sc_y = pcond_scaler_y
        # 对train、test进行scaler转换
        train_X_sc = sc_X.transform(train_X)
        train_y_sc = sc_y.transform(train_y)
        # eval_X_sc = sc_X.transform(eval_X)
        # eval_y_sc = sc_y.transform(eval_y)
        test_X_sc = sc_X.transform(test_X)
        test_y_sc = sc_y.transform(test_y)

        # 创建模型
        model = Sequential()

        # 添加输入层和第一个隐含层 input_dim=X.shape[1]以适应后期输入数据维度的变化
        model.add(Dense(units=16, input_dim=X.shape[1], activation='relu'))

        # 添加第二个隐含层
        model.add(Dense(units=8, activation='relu'))

        # 添加输出层
        model.add(Dense(units=1, activation='linear'))

        # 编译模型
        model.compile(loss='mae', optimizer='adam')

        # 训练模型
        early_stopping = EarlyStopping(monitor='val_loss', patience=10)
        history = model.fit(train_X_sc, train_y_sc, epochs=3000, batch_size=512,
                            validation_data=(test_X_sc, test_y_sc), callbacks=[early_stopping],verbose=0)
        # 绘制训练和验证损失随时间的变化图
        y_pred = sc_y.inverse_transform(model.predict(test_X_sc,verbose=0))
        y_true = sc_y.inverse_transform(test_y_sc)
        mape = mape_sklearn(y_true, y_pred)
        judge = 'Pass' if mape < 0.02 else 'Fall'
        print('训练完成，训练集上的mape:{:.4f},{}'.format(mape, judge))
        if judge == 'Pass':
            # 保存模型
            model.save('model/'+'{}_{}_pcond_params.h5'.format(self.system_id, self.device_name))
            # 保存归一化器scaler
            joblib.dump(sc_X, 'model/' +
                        '{}_{}_pcond_scaler_X'.format(
                            self.system_id,
                            self.device_name))
            joblib.dump(sc_y, 'model/' +
                        '{}_{}_pcond_scaler_y'.format(
                            self.system_id,
                            self.device_name))
            print('训练完成，保存模型')
        else:
            print('训练完成，不保存模型')

    def pcond_predict(self, X):
        model = load_model('model/'+'{}_{}_pcond_params.h5'.format(self.system_id, self.device_name))
        # X = self.pcond_get_data()[0]
        # X = X.to_numpy()
        X = np.reshape(X, (X.shape[0], X.shape[1]))

        # 读取scaler
        sc_X = joblib.load('model/' +
                           '{}_{}_pcond_scaler_X'.format(
                               self.system_id,
                               self.device_name))
        sc_y = joblib.load('model/' +
                           '{}_{}_pcond_scaler_y'.format(
                               self.system_id,
                               self.device_name))
        # 对X进行scaler
        X_sc = sc_X.transform(X)
        # 预测y，对y进行预测
        y_pred_sc = model.predict(X_sc,verbose=0) #用于pytorch模型     keras中两者等价
        # y_pred_sc = model.predict(X_sc) #用于sklearn模型
        # 反向调用scaler，输出原始的y
        y_pred = sc_y.inverse_transform(y_pred_sc)
        return y_pred

    #####################################Pcond部分结束###################################################


if __name__ == "__main__":

    # 单机头 (Cap:1700): 'dech01','dech02',
    # 双机头 (Cap:3200): 'dedch01','dedch02','dedch03','dedch04','dedch05','dedch06','dedch07','dedch08'

    # 单机头 (Cap:1700):
    for i in ['dech01', 'dech02']:
        # print(f' {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i} {i}')
        a = Chiller("174", i, 1700, 1775, 5, 535.6)
        # a.power_single_train(start_time='2022-11-01 00:00:00', end_time='2023-03-31 23:59:59')
        # X, Y, Z = a.power_single_get_data(start_time='2023-03-01 00:00:00', end_time='2023-06-30 23:59:59')
        # P = a.power_single_predict(X)
        a.pcond_train(start_time='2022-11-01 00:00:00', end_time='2023-03-31 23:59:59')
        X, Y, Z = a.pcond_get_data(start_time='2023-03-01 00:00:00', end_time='2023-06-30 23:59:59')
        P = a.pcond_predict(X)

        plt.scatter(Z['data_time'], Y, label='truth', color='blue')
        plt.scatter(Z['data_time'], P, label='predicted', color='orange')
        plt.legend()
        plt.show()

        # print(Y)
        # print(P)
        if len(Y) > 0:
            mape = mape_sklearn(Y, P)
            mae = mean_absolute_error(Y, P)
            print(i, mape, mae)
        else:
            print(i, '没数据')
        print('-------------------------------')

    # # 双机头 (Cap:3200):
    # for i in [
    #     'dedch01',
    #     'dedch02',
    #     'dedch03',
    #     'dedch04',
    #     'dedch05',
    #     'dedch06',
    #     'dedch07',
    #     'dedch08'
    #             ]:
    #     a = Chiller("174", i, 3200, 1775, 5, 535.6)
    #     a.power_double_train(start_time='2023-01-01 00:00:00', end_time='2023-07-20 23:59:59')
    #     X, Y, Z = a.power_double_get_data(start_time='2023-07-21 00:00:00', end_time='2023-08-30 00:00:00')
    #     P = a.power_double_predict(X)
    #     # print(Y)
    #     # print(P)
    #     if len(Y) > 0:
    #         mape = mape_sklearn(Y, P)
    #         mae = mean_absolute_error(Y, P)
    #         print(i, mape, mae)
    #     else:
    #         print(i, '没数据')
    #     print('-------------------------------')



        # plt.scatter(X, Y, label='truth', color='blue')
        # plt.scatter(X, P, label='predicted', color='orange')
        # plt.legend()
        # plt.show()

