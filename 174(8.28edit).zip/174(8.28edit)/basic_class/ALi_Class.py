from alibabacloud_iot20180120.client import Client as Iot20180120Client
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_iot20180120 import models as iot_20180120_models
from typing import List
import sys
class Local_2_AliCloud:
    def __init__(self):
        pass

    @staticmethod
    def create_client(
        access_key_id: str,
        access_key_secret: str,
    ) -> Iot20180120Client:
        """
        使用AK&SK初始化账号Client
        @param access_key_id:
        @param access_key_secret:
        @return: Client
        @throws Exception
        """
        config = open_api_models.Config(
            # 您的AccessKey ID,
            access_key_id=access_key_id,
            # 您的AccessKey Secret,
            access_key_secret=access_key_secret
        )
        # 访问的域名
        config.endpoint = 'iot.cn-shanghai.aliyuncs.com'
        return Iot20180120Client(config)

    @staticmethod
    def upload_tower_num(
        args: List[str],tower_num
    ) -> None:
        client = Local_2_AliCloud.create_client('LTAIIZzJXn8c3YFz', 'rlKLASKPvJXtcVEcRl39JzbRONDwkK')
        set_device_property_request = iot_20180120_models.SetDevicePropertyRequest(
            product_key='a1P5TqkRuVv',
            device_name='PLCCN',
            items='{{"rem_ct_num_st": {}}}'.format(tower_num)
        )
        # 复制代码运行请自行打印 API 的返回值
        client.set_device_property(set_device_property_request)
        print(client.set_device_property(set_device_property_request))

    @staticmethod
    def upload_decdwp_num(
        args: List[str],decdwp_num
    ) -> None:
        client = Local_2_AliCloud.create_client('LTAIIZzJXn8c3YFz', 'rlKLASKPvJXtcVEcRl39JzbRONDwkK')
        set_device_property_request = iot_20180120_models.SetDevicePropertyRequest(
            product_key='a1P5TqkRuVv',
            device_name='PLCCN',
            items='{{"rem_cowp_num_st": {}}}'.format(decdwp_num)
        )
        # 复制代码运行请自行打印 API 的返回值
        client.set_device_property(set_device_property_request)
        print(client.set_device_property(set_device_property_request))

    @staticmethod
    def upload_tower_out_temp(
        args: List[str],tower_out_temp
    ) -> None:
        client = Local_2_AliCloud.create_client('LTAIIZzJXn8c3YFz', 'rlKLASKPvJXtcVEcRl39JzbRONDwkK')
        set_device_property_request = iot_20180120_models.SetDevicePropertyRequest(
            product_key='a1P5TqkRuVv',
            device_name='PLCCN',
            items='{{"rem_ct_out_temp_st": {}}}'.format(tower_out_temp)
        )
        # 复制代码运行请自行打印 API 的返回值
        client.set_device_property(set_device_property_request)
        print(client.set_device_property(set_device_property_request))

    @staticmethod
    def upload_temp_delta(
        args: List[str],temp_delta
    ) -> None:
        client = Local_2_AliCloud.create_client('LTAIIZzJXn8c3YFz', 'rlKLASKPvJXtcVEcRl39JzbRONDwkK')
        set_device_property_request = iot_20180120_models.SetDevicePropertyRequest(
            product_key='a1P5TqkRuVv',
            device_name='PLCCN',
            items='{{"rem_cowp_dt_st": {}}}'.format(temp_delta)
        )
        # 复制代码运行请自行打印 API 的返回值
        client.set_device_property(set_device_property_request)
        print(client.set_device_property(set_device_property_request))

if __name__ == "__main__":
    a = Local_2_AliCloud()
    a.upload_decdwp_num(sys.argv[1:],round(3))