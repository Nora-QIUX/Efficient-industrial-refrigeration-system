import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
import sys
import matplotlib.pyplot as plt
# sys.path.append('/lib/algorithm/3051_lengquece_opt')
import os
# os.chdir('qiuxin/174(8.28edit)')
# os.chdir(r'D:/algorithm-library-tansuo/team_work')
# os.chdir(r'/lib/tools/algorithm/QQR_env/team_work')
from tools.tools import conn_000012
from keras.callbacks import EarlyStopping,ReduceLROnPlateau
import joblib
from sklearn.metrics import mean_absolute_percentage_error as mape_sklearn
from sklearn.model_selection import train_test_split
from keras.models import Sequential, load_model, Model
from keras.layers import Input, Dense, concatenate
from sklearn.preprocessing import MinMaxScaler
from adtk.detector import QuantileAD, LevelShiftAD
from sklearn.metrics import mean_absolute_error

'''
冷却塔类会看作一个冷却塔组的整体
这之中主要包含两个模型
#####################注意###################
1.冷却塔的散热模型
冷却塔散热模型需要改为黑箱模型，Nora需要把这块代码修改一下
X：【进塔水温、流量、风机总频率、室外湿球温度、室外温度】
其中风机总频率=单个频率*开机数量
进塔水温：decowp中的temp字段
流量：dech中所有的flow_2的流量之和
冷却塔总频率：dect中freq之和
室外湿球温度、室外温度：deth中的temp_outdoor和temp_wb_out_door
其余字段都可以在表中直接获取
Y：【出塔水温】
#####################注意###################
#####################注意###################
2.冷却塔的功率模型
输入:【总频率、开启数量、每台频率】
输出:【总电功率】
还是考虑用公式模型，这种模型会比较有实际意义
#####################注意###################
'''

pd.set_option('display.expand_frame_repr', False)
class Cooling_tower():

    def __init__(self, system_id, device_name, dect_num,dech_num,num = 1):
        '''
        :param system_id: 项目名
        :param device_name: 设备名
        :param dect_num：几台冷却塔
        通过项目名+设备名+功能save模型
        '''
        self.system_id = system_id
        self.device_name = device_name
        self.dect_num = dect_num
        self.dech_num = dech_num
        self.cpw = 4.2
        self.num = num
        self.pa = 1.293  # kg/m3
        # 上下四分位数筛选方法，参数设定
        self.quantile_ad = QuantileAD(high=0.8, low=0.2)
        # 根据突变斜率筛选方法，参数设定
        self.level_shift_ad = LevelShiftAD(c=1.0, side='both', window=20)

    def out_temp_fan_on_get_data(self, start_time, end_time):
        '''
        2023年5月10日14:35:50 取预测出塔水温所需的训练数据
        :param start_time: 时间开始日期
        :param end_time: 时间结束日期
        :return:
        '''
        # 拼sql
        sql1 = '''
        select data_time,temp as 冷却塔进水温度,temp-temp_2 as 温差,flow_instantaneous as 冷却总管流量,temp_2 as 冷却塔出水温度 
        from decowp_{}_l1
        where data_time
        between '{}' and '{}'
        '''.format(self.system_id, start_time, end_time)

        sql2 = '''
        select data_time,device_name,freq,power_active
        from dect_{}_l1
        where data_time
        between '{}' and '{}'
        '''.format(self.system_id, start_time, end_time)

        sql3 = '''
        select data_time,temp_outdoor as 室外温度,temp_wb_outdoor as 室外湿球温度
        from deth_{}_l1
        where data_time
        between '{}' and '{}'
        '''.format(self.system_id, start_time, end_time)

        sql4 = '''
        select data_time,device_name,flow_instantaneous_2,temp_cow_in,temp_cow_out 
        from dech_{0}_l1
        where data_time
        between '{1}' and '{2}'
        '''.format(self.system_id, start_time, end_time)


        conn = conn_000012
        d1 = pd.read_sql(sql1, con=conn)
        d2 = pd.read_sql(sql2, con=conn)
        d3 = pd.read_sql(sql3, con=conn)
        d4 = pd.read_sql(sql4, con=conn)
        # 计算每个时间戳下数据的条数，应该等于冷却塔的数量，如果不满足则后续会删除
        d2_count = d2.groupby(['data_time']).count().reset_index()[['data_time', 'freq']]
        d4_count = d4.groupby(['data_time']).count().reset_index()[['data_time', 'flow_instantaneous_2']]
        d2_count = d2_count[d2_count['freq'] == self.dect_num].reset_index(drop = True)
        d4_count = d4_count[d4_count['flow_instantaneous_2'] == self.dech_num].reset_index(drop=True)
        d4['Q_cond'] = d4['flow_instantaneous_2'] * (d4['temp_cow_out']-d4['temp_cow_in'])*4.1868*1000/3600
        d4['Q_cond'] = d4['Q_cond'].rolling(window = 10).mean()
        d4_sum = d4.groupby(['data_time']).sum(['flow_instantaneous_2,Q_cond']).reset_index()
        d4_sum = d4_sum[d4_sum['data_time'].isin(d4_count['data_time'])]


        # 计算freq>20的冷却塔，视为开启
        d2['open'] = d2['freq'].apply(lambda x: 1 if x > 10 else 0)
        # 计算冷却塔的总体数据即总频率、总电耗
        d2_sum = d2.groupby(['data_time']).sum().reset_index()[
            ['data_time', 'freq', 'power_active', 'open']]
        # 只保留正确的时间戳
        d2 = d2_sum[d2_sum['data_time'].isin(
            d2_count['data_time'])].reset_index(drop=True)
        # 计算对应的每台频率和每台功率
        d2['freq_per'] = d2['freq'] / d2['open']
        d2['power_active_per'] = d2['power_active'] / d2['open']
        # 拼接数据
        data = pd.merge(
            d1,
            d2,
            on='data_time',
            how = 'inner').sort_values(
            by='data_time')
        data = pd.merge(
            data,
            d3,
            on='data_time',
            how = 'inner').sort_values(
            by='data_time')
        data = pd.merge(
            data,
            d4_sum,
            on = 'data_time',
            how = 'inner').sort_values(
            by='data_time')
        data = data.rolling(window = 10).mean()
        # 数据清洗，按照一定规则清洗数据
        # detect_data = pd.DataFrame()
        # detect_data.index = data['data_time']
        # detect_data['flow_instantaneous_2'] = \
        #     data['flow_instantaneous_2'].values
        # detect_data['flag_1'] = self.level_shift_ad.fit_detect(
        #     detect_data['flow_instantaneous_2'])
        # detect_data['flag_2'] = self.quantile_ad.fit_detect(
        #     detect_data['flow_instantaneous_2'])
        # detect_data = detect_data.reset_index(drop=False)
        # 这里会自动对齐正确的index
        # data = data[(detect_data['flag_1'] == False) &
        #             (detect_data['flag_2'] == False)
        #             ].reset_index(drop=True)
        data = data[(data['冷却总管流量'] > 0) &
                    (data['Q_cond'] > 0) &
                    (data['温差'] > 0) &
                    # (data['温差'] <= 5.5) &
                    (data['freq'] > 0) &
                    (data['power_active'] > 0) &
                    (data['open'] > 0) &
                    # (data['open']  ==3) &
                    (data['freq_per'] <= 50) &
                    (data['freq_per'] > 0) &
                    (data['power_active_per'] < 50) &
                    (data['冷却塔出水温度'] > 15)].reset_index(drop=True)

        # data['data_time'] = pd.to_datetime(
        #     data['data_time']).dt.strftime('%Y-%m-%d %H:00:00')
        #
        # data_mean = data.groupby(['data_time']).mean().reset_index()

        data = data.dropna().reset_index(drop=True)
        # data['冷却塔出水温度'] = round(data['冷却塔出水温度'],1)

        # 确定入模变量
        X = data[[
                  # '冷却总管流量'
                  # 'Q_cond',
                  'flow_instantaneous_2'
                  ,'freq'
                  # , '冷却塔进水温度'
                  # , 'power_active'
                  # , 'open'
                  # , 'freq_per'
                  # , 'power_active_per'
                  , '室外温度'
                  , '室外湿球温度']].values
        # 确定输出
        Y = data[['冷却塔出水温度']].values
        return X, Y

        ################# 使用了xgb这里也没用了#################

    def out_temp_fan_on_fun(self, X, *params):
        '''
        :param X:
        f: 风机频率，Hz
        Vctw: 冷却塔水流量，kg/s
        t_ctwin: 冷却塔进水温度，℃
        h_ain: 进风焓值， kj/kg
        h_actwin: 冷却塔进口水温下的饱和空气焓值， kj/kg
        :param paras:
        代拟合的参数[a1,a2,b1,b2]
        :return: t_ctwout 冷却塔出水温度，℃
        '''
        f = X[0]  # Va
        Vctw = X[1]  # m3/h
        t_ctwin = X[2]
        h_ain = X[3]
        h_actwin = X[4]
        a1, a2, b1, b2 = params
        B = b1 * (f / Vctw)
        mc = b2 * B
        NTU = a1 * pow(B, -a2)
        epsilon = (1 - np.exp(-NTU * (1 - mc))) / \
                  (1 - mc * np.exp(-NTU * (1 - mc)))
        t_ctwout = t_ctwin - (epsilon * B * (h_actwin - h_ain) / self.cpw)
        return t_ctwout

    ################# 使用了xgb这里也没用了#################

    def out_temp_fan_on_train(self, start_time, end_time):
        '''
        训练模型
        通过传入的start_time,end_time，训练模型
        :param start_time:
        :param end_time:
        :return:
        '''
        # 获取对应数据
        X, Y = self.out_temp_fan_on_get_data(start_time, end_time)
        # 分割数据集
        train_X, test_X, train_y, test_y = train_test_split(X, Y,shuffle=True)
        # train_X, eval_X, train_y, eval_y = train_test_split(X, Y)
        # 制作对应的X，y的scaler
        out_temp_fan_on_scaler_X = MinMaxScaler()
        out_temp_fan_on_scaler_y = MinMaxScaler()
        # 用训练数据fitscaler，如果用全量数据会导致数据泄露
        out_temp_fan_on_scaler_X.fit(train_X)
        out_temp_fan_on_scaler_y.fit(train_y)
        sc_X = out_temp_fan_on_scaler_X
        sc_y = out_temp_fan_on_scaler_y
        # 对train、test进行scaler转换
        train_X_sc = sc_X.transform(train_X)
        train_y_sc = sc_y.transform(train_y)
        # eval_X_sc = sc_X.transform(eval_X)
        # eval_y_sc = sc_y.transform(eval_y)
        test_X_sc = sc_X.transform(test_X)
        test_y_sc = sc_y.transform(test_y)
        train_1 = train_X_sc[:, [0,1]]
        # train_2 = train_X_sc[:, [1]]
        train_3 = train_X_sc[:, [2, 3]]
        test_1 = test_X_sc[:, [0,1]]
        # test_2 = test_X_sc[:, [1]]
        test_3 = test_X_sc[:, [2, 3]]
        # 定义第一个输入层
        input1 = Input(shape=(2,))

        # 定义第二个输入层
        # input2 = Input(shape=(1,))

        # 定义第二个输入层
        input3 = Input(shape=(2,))

        # 构建第一个全连接层
        dense1 = Dense(16, activation='relu')(input1)

        # 构建第二个全连接层
        # dense2 = Dense(8, activation='relu')(input2)

        # 构建第二个全连接层
        dense3 = Dense(16, activation='relu')(input3)

        # 将两个全连接层合并
        merge = concatenate([dense1, dense3])

        # dense4 = Dense(32, activation='relu')(merge)

        # 构建输出层
        output = Dense(1, activation='linear')(merge)

        # 创建模型
        model = Model(inputs=[input1, input3], outputs=output)

        model.compile(optimizer='adam', loss='mse')
        # 训练模型
        early_stopping = EarlyStopping(monitor='val_loss', patience=10)
        reduce_lr = ReduceLROnPlateau(factor=0.8, patience=30)

        history = model.fit([train_1,train_3], train_y_sc, epochs=3000, batch_size=64,
                            validation_data=([test_1,test_3], test_y_sc), callbacks=[early_stopping],verbose=0)
        # 输出y

        y_pred = sc_y.inverse_transform(model.predict([test_1,test_3],verbose=0))
        y_true = sc_y.inverse_transform(test_y_sc)
        mape = mape_sklearn(y_true, y_pred)
        # 进行评价
        judge = 'Pass' if mape < 0.025 else 'Fall'
        print('训练完成，训练集上的mape:{:.4f},{}'.format(mape, judge))
        if judge == 'Pass':
            model.save('model/' +
                       '{}_{}_out_temp_fan_on_model.h5'.format(
                           self.system_id,
                           self.device_name))
            joblib.dump(out_temp_fan_on_scaler_X, 'model/' +
                        '{}_{}_out_temp_fan_on_scaler_X'.format(
                            self.system_id,
                            self.device_name))
            joblib.dump(out_temp_fan_on_scaler_y, 'model/' +
                        '{}_{}_out_temp_fan_on_scaler_y'.format(
                            self.system_id,
                            self.device_name))
            print('训练完成，保存模型')
        else:
            print('训练完成，不保存模型')

    def out_temp_fan_on_predict(self, X):
        '''
        输出数据进行predict
        :param X:
        :return:
        '''
        # 读取模型
        X = X
        model = load_model('model/' +
                           '{}_{}_out_temp_fan_on_model.h5'.format(
                               self.system_id,
                               self.device_name))
        # 读取scaler
        sc_X = joblib.load('model/' +
                           '{}_{}_out_temp_fan_on_scaler_X'.format(
                               self.system_id,
                               self.device_name))
        sc_y = joblib.load('model/' +
                           '{}_{}_out_temp_fan_on_scaler_y'.format(
                               self.system_id,
                               self.device_name))
        # 对X进行scaler
        X_sc = sc_X.transform(X)
        X1 = X_sc[:, [0, 1]]
        X3 = X_sc[:, [2, 3]]
        # 预测y，对y进行预测
        y_pred = model.predict([X1,X3],verbose=0)
        # 调用scaler，输出正确的y
        y_pred_sc = sc_y.inverse_transform(y_pred)
        return y_pred_sc










    ################# power 开始#################

    def power_get_data(self, start_time, end_time):
        '''
        获取电耗模型需要的数据
        :param start_time:
        :param end_time:
        :return:
        '''

        sql = '''
        select * from dect_{}_l1
        where data_time
        between '{}' and '{}'
        '''.format(self.system_id, start_time, end_time)
        # 获取数据库的连接
        conn = conn_000012
        data = pd.read_sql(sql, con=conn)
        # 数据预处理+数据清洗
        data['open'] = data['freq'].apply(lambda x: 1 if x > 10 else 0)
        # plt.scatter(data['data_time'], data['freq'], label='freq')
        # plt.scatter(data['data_time'], data['open'], label='open')
        # plt.show()
        # 计算每个时间戳下的有效数据，有缺失的不要，全关着的不要
        d1 = data.groupby(['data_time']).count().reset_index()[
            ['data_time', 'open']]
        d1 = d1[(d1['open'] == self.dect_num) & (d1['open'] > 0)]
        # 计算冷却塔电量、频率、开启数量之和
        d2 = data.groupby(['data_time']).sum().reset_index()[
            ['data_time', 'freq', 'open', 'power_active']]
        d2_rolling = d2.rolling(window = 1).mean()
        d2_rolling['data_time'] = d2['data_time']
        d2 = d2_rolling.dropna().reset_index(drop = True)
        df = d2[d2['data_time'].isin(d1['data_time'])].reset_index(drop=True)
        # print(df.shape)
        # plt.scatter(df['data_time'], df['freq'], label='freq')
        # plt.scatter(df['data_time'], df['open'], label='open')
        # plt.show()

        df = df[(df['open'] > 0)]
        # print(df.shape)

        # 处理每台的数据
        df['freq_per'] = df['freq'] / df['open']
        df['power_active_per'] = df['power_active'] / df['open']
        df = df.dropna()
        # 根据每台数据阈值，再筛选数据
        df = df[(df['power_active_per'] < 50)
                & (df['freq_per'] <= 50)
                & (df['power_active_per'] > 0)].reset_index(drop=True)
        # 输入变量 总频率、开启的台数、单一频率
        X = df[['freq_per']].values
        Y = df[['power_active_per']].values
        return X, Y

    def power_fun(self, X, *params):
        '''
        输入 频率
        :param X:
        :param params:
        :return:
        '''
        freq = X
        c1, c2, c3,c4 = params
        power = (c1 * freq + c2 * pow(freq, 2) + c3 * pow(freq, 3))+ c4
        return power

    def power_train(self, start_time, end_time):
        '''
        训练参数模型
        :param start_time:
        :param end_time:
        :return:
        '''
        X, Y = self.power_get_data(start_time, end_time)
        X = X.reshape(1, -1)[0]
        Y = Y.reshape(1, -1)[0]
        func = self.power_fun
        p0 = [1, 1, 1, 1]
        try:
            popt, pcov = curve_fit(func, X, Y, p0=p0, maxfev=50000)
        except BaseException:
            popt = p0
        # 存popt
        np.save('model/' +
                '{}_{}_power_params'.format(self.system_id, self.device_name), popt)

    def power_predict(self, X, num):
        '''
        输入频率和开启的数量，默认为1
        :param X:
        :param num:
        :return:
        '''
        # 取参数
        X = X.reshape(1, -1)[0]
        params = np.load(
            'model/' +
            '{}_{}_power_params.npy'.format(
                self.system_id,
                self.device_name
            ))
        c1, c2, c3, c4 = params
        power = np.array(self.power_fun(X,  c1, c2, c3, c4))
        return power*num

    ################# power 结束#################








if __name__ == "__main__":
    import matplotlib.pyplot as plt
    # 实例化验证步骤
    # a = Cooling_tower('174', 'dect_all', 22, 10)
    # a.out_temp_fan_on_train(start_time='2023-04-01 00:00:00', end_time='2023-08-25 23:59:00')
    import matplotlib.pyplot as plt
    # a.out_temp_without_train(start_time='2023-04-01 00:00:00', end_time='2023-06-27 23:59:00')
    # a.out_temp_fan_off_train(start_time='2023-04-01 00:00:00', end_time='2023-06-27 23:59:00')
    # a.out_temp_fan_on_train(start_time='2023-04-01 00:00:00', end_time='2023-06-28 23:59:00')
    # X, Y = a.out_temp_fan_on_get_data(start_time='2023-08-26 00:00:00', end_time='2023-08-28 14:00:00')
    # a.out_temp_fan_on_predict(np.array([[1100,109,28,24]]))


    # a.Et_train(start_time='2023-03-01 00:00:00', end_time='2023-06-25 23:59:00')
    # X =a.Et_get_data(
    #         start_time='2023-05-28 00:00:00',
    #         end_time='2023-05-28 23:10:00')[0]
    #
    # Y =a.Et_get_data(
    #         start_time='2023-05-28 00:00:00',
    #         end_time='2023-05-28 23:10:00')[1]
    # P = a.Et_predict(a.Et_get_data(
    #         start_time='2023-05-28 00:00:00',
    #         end_time='2023-05-28 23:10:00')[0])
    # plt.plot(P,label = 'Predict')
    # plt.plot(Y,label = 'True')
    # plt.legend()
    # plt.show()
    # plt.ylim(bottom = 10,top = 30)
    # plt.show()

    # 3051中，
    # 实例测试预测电量
    # a.power_train(start_time='2023-07-01 00:00:00', end_time='2023-07-20 00:00:00')
    # a.out_temp_without_train(start_time='2023-03-01 00:00:00', end_time='2023-08-03 13:59:00')
    # a.out_temp_fan_off_train(start_time='2023-03-01 00:00:00', end_time='2023-06-06 13:59:00')
    # 测试一下
    # a.power_predict(
    #     a.power_get_data(
    #         start_time='2023-05-29 00:00:00',
    #         end_time='2023-05-29 09:10:00')[0])
    # 实例测试预测出塔水温f
    # a.out_temp_fan_off_train(
    #     start_time='2023-03-01 00:00:00',
    #     end_time='2023-05-29 12:00:00')
    # 测试一下
    # a.power_train(
    #     start_time='2023-05-15 00:00:00',
    #     end_time='2023-06-05 09:00:00')
    # X,Y = a.power_get_data(
    #     start_time='2023-05-15 00:00:00',
    #     end_time='2023-06-05 09:00:00')
    # X
    # P = a.power_predict(X,1)
    # print(P)
    # print(Y)
    # print(mape_sklearn(y_true=Y ,
    #              y_pred=a.power_predict(X,1)))
    # pd.DataFrame([[P],[Y]])
    # data = pd.concat([pd.DataFrame(X),pd.DataFrame(Y)],axis =1)
    # data['predict'] = a.power_predict(X,1)

    # 8070.526000000001, 904.28, 30.880000000000003,28.359999999999996




    a = Cooling_tower('174', 'dect_all', 22, 10)
    a.power_train(start_time='2023-03-01 00:00:00', end_time='2023-07-20 23:59:59')
    X, Y = a.power_get_data(start_time='2023-07-21 00:00:00', end_time='2023-08-28 10:00:00')
    P = a.power_predict(a.power_get_data(start_time='2023-07-21 00:00:00', end_time='2023-08-28 10:00:00')[0],1)
    # print(Y)
    # print(P)
    mape = mape_sklearn(Y, P)
    mae = mean_absolute_error(Y, P)
    print(mape, mae)
    plt.scatter(X, Y, label='truth', color='blue')
    plt.scatter(X, P, label='predicted', color='orange')
    plt.legend()
    plt.show()





