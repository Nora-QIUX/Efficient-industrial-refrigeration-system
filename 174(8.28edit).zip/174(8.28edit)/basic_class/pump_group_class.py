import pandas as pd
import numpy as np

class Pump_group():
    def __init__(self, pump_list:list):
        self.pump_list = pump_list
        self.pump_num = len(pump_list)
        self.device_name_list = [i.device_name for i in self.pump_list]
    def group_power_predict(self,X_dict,on_off_list):
        '''
        :param X_dict:{'dech':pd.DataFrame(对应的输入).values}
        :param on_off_list: [1,1,1]
        :return: 电量合
        '''
        power_list = []
        for i in range(len(self.pump_list)):
            X = X_dict[self.pump_list[i].device_name]
            Y = self.pump_list[i].power_predict(X)
            Y = Y * on_off_list[i]
            power_list.append(Y)
            # power_list.append(Y)
        return np.nan_to_num(np.array(power_list), nan=0).sum(axis = 0)
if __name__ == "__main__":
    pump_dict = {}


