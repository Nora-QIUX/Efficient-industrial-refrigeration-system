from matplotlib import pyplot as plt
from sqlalchemy.dialects.postgresql import psycopg2

from tools.tools import conn_000012
import pandas as pd



if __name__ == "__main__":
    conn = conn_000012
    # sql1 = '''
    #         select * from decdwp_{0}_l1
    #         where data_time
    #         between '{1}' and '{2}'
    #         '''.format(174, '2023-03-20 00:00:00', '2023-08-29 09:00:00')
    # data1 = pd.read_sql(sql1, con=conn)
    # data1['hour'] = data1['data_time'].dt.floor('H')  # 提取小时并进行分组
    # result_df = data1.groupby(['hour', 'device_name'], as_index=False).mean()
    # print('data1读完了')
    # result_df.to_csv('DECDWP_A9A10_after3.20_Hour.csv')


for i, j in [
          ['2022-11-01 00:00:00', '2022-11-30 00:00:00'],
          ['2022-12-01 00:00:00', '2022-12-30 00:00:00'],
          ['2023-01-01 00:00:00', '2023-01-30 00:00:00'],
          ['2023-02-01 00:00:00', '2023-02-26 00:00:00'],
          ['2023-03-01 00:00:00', '2023-03-30 00:00:00'],
          ['2023-04-01 00:00:00', '2023-04-30 00:00:00'],
          ['2023-05-01 00:00:00', '2023-05-30 00:00:00'],
          ['2023-06-01 00:00:00', '2023-06-30 00:00:00'],
          ['2023-07-01 00:00:00', '2023-07-30 00:00:00'],
          ['2023-08-01 00:00:00', '2023-08-30 00:00:00']
          ]:
    sql2 = '''
            select * from dech_{0}_l1
            where data_time
            between '{1}' and '{2}'
            and (device_name = 'dedch01' OR
                 device_name = 'dedch02' OR
                 device_name = 'dedch03')
            '''.format(174, i, j)
    conn = conn_000012
    df = pd.read_sql(sql2, con=conn)
    # data2['hour'] = data2['data_time'].dt.floor('H')  # 提取小时并进行分组
    # result_df = data2.groupby(['hour', 'device_name'], as_index=False).mean()
    # df = df.groupby(['data_time', 'device_name'])['flow_instantaneous_2'].mean().reset_index()
    pivot_df = df.pivot(index='data_time', columns='device_name', values='flow_instantaneous_2')
    print(pivot_df)
    # 绘制图表
    pivot_df.plot(figsize=(12, 6))  # 调整图表大小
    plt.xlabel('Data Time')
    plt.ylabel('Flow')
    plt.title(f'{i}~{j}')
    plt.legend(title='Device Name')  # 添加图例，显示机器名称
    plt.grid(True)  # 添加网格线

    i_short = i[5:7]
    plt.savefig(f'adjustment9.1/wp1-wp3 flow pump {i_short}月.png')

    plt.show()

    # data2.to_csv('DECH_A9A10_after3.20_Hour.csv')

    # pgsql_dict = {
    #     'database': "discovery_000012",
    #     'username': "tsnyadmin",
    #     'password': "Tsny2020",
    #     'host': "pgm-0jl416j2noxs2x83bo.pg.rds.aliyuncs.com", 'port': "5432"
    # }
    # conn_000012 = psycopg2.connect(
    #     database='discovery_000012',
    #     user=pgsql_dict.get('username'),
    #     password=pgsql_dict.get('password'),
    #     host=pgsql_dict.get('host'),
    #     port="5432")
    #
    # sql='''
    # select device_name, data_time, status_switch
    # from dech_174_l1
    # WHERE data_time >= '2023-05-05 10:00:00.000000'
    # AND data_time <= '2023-08-05 10:00:00.000000'
    # AND status_switch = 1
    # '''
    # df=pd.read_sql(sql, conn_000012)
    # df.to_csv('adjustment9.1/filtered_df.csv')