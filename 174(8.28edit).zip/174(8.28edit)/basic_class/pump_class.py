import pandas as pd
import numpy as np
import sys
import matplotlib as plt
# sys.path.append('/lib/tools/algorithm/QQR_env')
import os
# os.chdir(r'D:/algorithm-library-tansuo/team_work')
# os.chdir('/lib/tools/algorithm/QQR_env/team_work')
sys.path.append('/lib/algorithm/3051_lengquece_opt')
import logging
from scipy.optimize import curve_fit
from adtk.detector import QuantileAD, LevelShiftAD
from tools.tools import conn_000012
from keras.callbacks import EarlyStopping
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_percentage_error as mape_sklearn
from sklearn.metrics import mean_absolute_error as mae_sklearn
from sklearn.model_selection import train_test_split
from keras.models import Sequential, load_model
from keras.layers import Dense, Dropout
import joblib
from sklearn.linear_model import RANSACRegressor,LinearRegression
from joblib import dump
from sklearn.metrics import mean_absolute_error
pd.set_option('display.expand_frame_repr', False)

class Decdwp_pump():
    def __init__(self, system_id, device_name, decdwp_num,
                 dech_num, Hz_rated=50):
        '''
        并联水泵组，直接视作一个整体进行建模
        :param system_id:
        :param device_name:
        :param decdwp_num:
        :param dech_num:
        :param Hz_rated:
        :param num: 开启水泵的数量设置，只会影响输出时的结果
        '''
        self.system_id = system_id
        self.device_name = device_name
        self.Hz = Hz_rated
        self.decdwp_num = decdwp_num
        self.dech_num = dech_num
        # 上下四分位数筛选方法，参数设定
        self.quantile_ad = QuantileAD(high=0.8, low=0.2)
        # 根据突变斜率筛选方法，参数设定
        self.level_shift_ad = LevelShiftAD(c=1.0, side='both', window=20)

        def detect_outliers(df):
            # 创建iforest模型
            model = IsolationForest()
            # 拟合模型
            model.fit(df)
            # 预测每个数据点是否为异常值
            outliers = model.predict(df)
            # 将结果添加到数据框中
            out_frame = pd.DataFrame()
            out_frame['outlier'] = outliers
            return out_frame
            # except:
            #     return np.nan
        self.detect_outliers = detect_outliers

    def power_get_data(self, start_time, end_time):
        '''
        获取计算水泵功率的数据，可以优化
        :param start_time:
        :param end_time:
        :return:
        '''
        sql = '''
        select data_time,freq,power_active 
        from decdwp_{}_l1
        where device_name = '{}'
        and data_time between '{}' and '{}'         
        '''.format(self.system_id, self.device_name, start_time, end_time)
        # 获取数据库的连接
        conn = conn_000012
        data = pd.read_sql(sql, con=conn)
        # 数据预处理+数据清洗
        data['open'] = data['freq'].apply(lambda x: 1 if x > 10 else 0)
        # # 计算每个时间戳下的有效数据，有缺失的不要，全关着的不要
        # d1 = data.groupby(['data_time']).count().reset_index()[
        #     ['data_time', 'open']]
        # d1 = d1[(d1['open'] == self.decdwp_num) & (d1['open'] > 0)]
        # # 计算冷却塔电量、频率、开启数量之和
        # d2 = data.groupby(['data_time']).sum().reset_index()[
        #     ['data_time', 'freq', 'open', 'power_active']]
        # df = d2[d2['data_time'].isin(d1['data_time'])].reset_index(drop=True)
        df = data[(data['open'] > 0)]
        # # 处理每台的数据
        # df['freq_per'] = df['freq'] / df['open']
        # df['power_active_per'] = df['power_active'] / df['open']
        df = df.dropna()
        # 根据每台数据阈值，再筛选数据
        # df.to_csv('pump_data_Apr~Aug.csv')
        # df = df[(df['power_active_per'] < 80)
        #         & (df['freq_per'] <= 50)
        #         & (df['power_active_per'] > 5)
        #         & (df['freq_per'] > 30)
        #         ].reset_index(drop=True)
        df = df[(df['power_active'] < 200)
                & (df['freq'] <= 55)
                & (df['power_active'] > 20)
                & (df['freq'] > 30)
                ].reset_index(drop=True)
        # 输入变量 总频率、开启的台数、单一频率


        X = df[['freq']].values
        Y = df[['power_active']].values
        return X, Y

    def power_fun(self, X, *params):
        '''
        水泵功率模型
        :param X: 输入为freq，Hz
        :param params:
        :return:
        '''
        freq = X
        c0, c1, c2, c3 = params
        power = (c0 + c1 * freq + c2 * pow(freq, 2) + c3 * pow(freq, 3))
        return power

    def power_train(self, start_time, end_time):
        '''
        训练参数模型
        :param start_time:
        :param end_time:
        :return:
        '''
        X, Y = self.power_get_data(start_time, end_time)
        X = X.reshape(1, -1)[0]
        Y = Y.reshape(1, -1)[0]
        func = self.power_fun
        p0 = [1, 1, 1, 1]
        try:
            popt, pcov = curve_fit(func, X, Y, p0=p0, maxfev=50000)
        except BaseException:
            popt = p0
        # 存popt
        np.save('model/' +
                '{}_{}_power_params'.format(self.system_id, self.device_name), popt)

    def power_predict(self, X):
        '''
        输入频率
        :param X:
        :param num:
        :return:
        '''
        # 取参数
        X = X.reshape(1, -1)[0]
        params = np.load(
            'model/' +
            '{}_{}_power_params.npy'.format(
                self.system_id,
                self.device_name
            ))
        c0, c1, c2, c3 = params
        power = np.array(self.power_fun(X, c0, c1, c2, c3))
        return power





    def flow_instantaneous_get_data(self, start_time, end_time):
        '''
        这一段非常复杂
        :param start_time:
        :param end_time:
        :return:
        '''
        sql1 = '''
        select data_time,device_name,freq,(pr_2-pr_3) as delta_pr 
        from decdwp_{}_l1
        where device_name = '{}'
        and data_time between '{}' and '{}'        
        '''.format(self.system_id, self.device_name, start_time, end_time)
        # 获取数据库的连接


        name_mapping = {
             'decdwp01': 'dedch01',
             'decdwp02': 'dedch02',
             'decdwp03': 'dedch03',
             'decdwp04': 'dedch04',
             'decdwp05': 'dedch05',
             'decdwp06': 'dedch06',
             'decdwp07': 'dedch07',
             'decdwp08': 'dedch08',
             'decdwp09':  'dech01',
             'decdwp10':  'dech02'
        }
        sql2 = '''
        select data_time,device_name,power_active,flow_instantaneous_2 
        from dech_{}_l1
        where device_name = '{}'
        and data_time between '{}' and '{}'
        '''.format(self.system_id, name_mapping.get(self.device_name, self.device_name), start_time, end_time)
        conn = conn_000012
        d1 = pd.read_sql(sql1, con=conn)
        d2 = pd.read_sql(sql2, con=conn)

        # 判断开or关
        d1['open'] = d1['freq'].apply(lambda x: 1 if x > 20 else 0)
        # d1中，字段包括data_time,device_name,freq,pr_2,pr_3求所有正确时间戳下的和
        d1['delta_pr'] = d1['delta_pr'].apply(lambda x:x if x>0 else 0)

        # 拼在一起
        data = pd.merge(d1, d2, how='inner', on='data_time')

        # 数据清洗+数据处理
        # 数据筛序

        data = data[
            (data['open'] > 0) &
            (data['flow_instantaneous_2'] > 1500) &
            (data['flow_instantaneous_2'] < 3000) &
            (data['freq'] <= 55) &
            (data['freq'] > 30) &
            (data['delta_pr']) > 0].reset_index(drop=True)
        data['energy'] = data['flow_instantaneous_2'] * data['delta_pr']
        # data['energy'] = data['flow_instantaneous_2'] * data['delta_pr_per']
        # 利用adtk筛选平滑数据
        # detect_data = pd.DataFrame()
        # detect_data.index = data['data_time']
        # detect_data['flow_instantaneous_2_per'] = \
        #     data['flow_instantaneous_2_per'].values
        # detect_data['flag_1'] = self.level_shift_ad.fit_detect(
        #     detect_data['flow_instantaneous_2_per'])
        # detect_data['flag_2'] = self.quantile_ad.fit_detect(
        #     detect_data['flow_instantaneous_2_per'])
        # detect_data = detect_data.reset_index(drop=False)
        # 这里会自动对齐正确的index
        # data = data[(detect_data['flag_1'] == False) &
        #             (detect_data['flag_2'] == False)
        #             ].reset_index(drop=True)

        # 准备每小时平均处理
        # data['data_time'] = pd.to_datetime(
        #     data['data_time']).dt.strftime('%Y-%m-%d %H:00:00')
        # 获取每小时的平均数据
        # data_mean = data.groupby(['data_time']).mean(
        # )[['flow_instantaneous_2_per', 'freq_per', 'delta_pr_per','freq','delta_pr']].reset_index()
        # 获取数据中的最大频率、最小频率
        # freq_min = int(data['freq_per'].min()) - 1
        # freq_max = int(data['freq_per'].max()) + 1
        # 根据频率进行分箱
        # data_mean['freq_per_cut'] = pd.cut(
        #     data_mean['freq_per'], bins=range(
        #         freq_min, freq_max, 1), labels=[
        #         i for i in range(
        #             freq_min, freq_max - 1)])
        # 准备进行异常处理
        # to_dect_list = data_mean.groupby(['freq_per_cut']).count().reset_index()[
        #     ['freq_per_cut', 'freq_per']]
        # to_dect_list.columns = ['freq_per_cut', 'count']
        # tmp_frame_plus = pd.DataFrame()
        # 对每一个频率进行异常处理
        # for i in range(to_dect_list.shape[0]):
        #     # 这个频率下的数据量超过了10则处理
        #     if to_dect_list['count'][i] > 10:
        #         temp_frame = data_mean[data_mean['freq_per_cut']
        #                                == to_dect_list['freq_per_cut'][i]]
        #         # 孤立森林
        #         Iforest = IsolationForest(n_estimators=20, bootstrap=False,contamination=0.01)
        #         # 打标
        #         temp_frame['flag'] = Iforest.fit_predict(
        #             temp_frame[['freq_per', 'flow_instantaneous_2_per', 'delta_pr_per']])
        #         # 添加标记数据
        #         tmp_frame_plus = tmp_frame_plus.append(temp_frame)
        #         # data_mean['flag'] = temp_frame['flag']
        #     else:
        #         pass
        # index会对齐，然后打上异常标记
        # data_mean['flag'] = tmp_frame_plus['flag']
        # 只要正确的数据
        # data_mean = data_mean[data_mean['flag'] == 1].reset_index(drop=True)
        # 拿出入模变量
        # X = data_mean[['freq_per', 'delta_pr_per']]
        # Y = data_mean[['flow_instantaneous_2_per']]
        # data['X'] = data['freq_per'] / data['delta_pr_per']
        # data['X_square'] = data['X'] * data['X']
        # data['flow_pr'] = data['flow_instantaneous_2'] * data['delta_pr_per']

        X = data[['freq']].values
        Y = data[['energy']].values
        Z = data[['delta_pr']].values
        F = data[['flow_instantaneous_2']].values
        return X, Y, Z, F

    def flow_instantaneous_fun(self, X, *params):
        '''
        输入 频率
        :param X:
        :param params:
        :return:
        '''
        freq = X[0]
        delta_pr = X[1]
        c0, c1, c2 = params
        power = (c0 + c1 * freq)/delta_pr
        return power

    def flow_instantaneous_train_test(self, start_time, end_time):
        # X, Y = self.flow_instantaneous_get_data(start_time, end_time, num)
        X, Y, Z, F = self.flow_instantaneous_get_data(start_time, end_time)
        # X = np.concatenate((X, X * X), axis=1)
        train_X, test_X, train_y, test_y = train_test_split(X, Y)
        # train_X, eval_X, train_y, eval_y = train_test_split(X, Y)
        # 制作对应的X，y的scaler
        flow_instantaneous_scaler_X = MinMaxScaler()
        flow_instantaneous_scaler_y = MinMaxScaler()
        # 用训练数据fitscaler，如果用全量数据会导致数据泄露
        flow_instantaneous_scaler_X.fit(train_X)
        flow_instantaneous_scaler_y.fit(train_y)
        # 保存scaler
        sc_X = flow_instantaneous_scaler_X
        sc_y = flow_instantaneous_scaler_y
        train_X_sc = sc_X.transform(train_X)
        train_y_sc = sc_y.transform(train_y)
        # eval_X_sc = sc_X.transform(eval_X)
        # eval_y_sc = sc_y.transform(eval_y)
        test_X_sc = sc_X.transform(test_X)
        test_y_sc = sc_y.transform(test_y)
        linear_model = LinearRegression()
        model = RANSACRegressor(base_estimator=linear_model,
                         max_trials=200,
                         random_state=42)
        model.fit(train_X_sc,train_y_sc)
        y_pred = sc_y.inverse_transform(model.predict(test_X_sc))
        y_true = sc_y.inverse_transform(test_y_sc)
        mape = mape_sklearn(y_true, y_pred)
        # judge = 'Pass' if mape < 0.08 else 'Fall'
        judge = 'Pass' if mape < 0.5 else 'Fall'
        print('训练完成，训练集上的mape:{:.4f},{}'.format(mape, judge))
        if judge == 'Pass':
            joblib.dump(model,'model/' +
                       '{}_{}_flow_instantaneous_model'.format(
                           self.system_id,
                           self.device_name))
            joblib.dump(flow_instantaneous_scaler_X, 'model/' +
                        '{}_{}_flow_instantaneous_scaler_X'.format(
                            self.system_id,
                            self.device_name))
            joblib.dump(flow_instantaneous_scaler_y, 'model/' +
                        '{}_{}_flow_instantaneous_scaler_y'.format(
                            self.system_id,
                            self.device_name))
            print('训练完成，保存模型')
        else:
            print('训练完成，不保存模型')

    def flow_instantaneous_train(self, start_time, end_time, num):
        '''
        训练参数模型
        :param start_time:
        :param end_time:
        :return:
        '''
        X, Y = self.flow_instantaneous_get_data(start_time, end_time,num)
        # X = X.values
        # Y = Y.values
        # 分割数据集
        train_X, test_X, train_y, test_y = train_test_split(X, Y)
        # train_X, eval_X, train_y, eval_y = train_test_split(X, Y)
        # 制作对应的X，y的scaler
        flow_instantaneous_scaler_X = MinMaxScaler()
        flow_instantaneous_scaler_y = MinMaxScaler()
        # 用训练数据fitscaler，如果用全量数据会导致数据泄露
        flow_instantaneous_scaler_X.fit(train_X)
        flow_instantaneous_scaler_y.fit(train_y)
        # 保存scaler
        sc_X = flow_instantaneous_scaler_X
        sc_y = flow_instantaneous_scaler_y
        train_X_sc = sc_X.transform(train_X)
        train_y_sc = sc_y.transform(train_y)
        # eval_X_sc = sc_X.transform(eval_X)
        # eval_y_sc = sc_y.transform(eval_y)
        test_X_sc = sc_X.transform(test_X)
        test_y_sc = sc_y.transform(test_y)
        # 构建模型
        model = Sequential()

        # 添加输入层和第一个隐含层
        model.add(Dense(units=128, input_dim=X.shape[1], activation='relu'))
        # 添加第二个隐含层
        model.add(Dense(units=32, activation='relu'))
        # 添加输出层
        model.add(Dense(units=1, activation='linear'))
        # 编译模型
        model.compile(loss='mae', optimizer='adam')
        # 训练模型
        early_stopping = EarlyStopping(monitor='val_loss', patience=60)
        history = model.fit(train_X_sc, train_y_sc, epochs=3000, batch_size=512,
                            validation_data=(test_X_sc, test_y_sc), callbacks=[early_stopping])
        # 输出y
        y_pred = sc_y.inverse_transform(model.predict(test_X_sc))
        y_true = sc_y.inverse_transform(test_y_sc)
        mape = mape_sklearn(y_true, y_pred)
        judge = 'Pass' if mape < 0.08 else 'Fall'
        print('训练完成，训练集上的mape:{:.4f},{}'.format(mape, judge))
        if judge == 'Pass':
            model.save('model/' +
                       '{}_{}_flow_instantaneous_{}_model.h5'.format(
                           self.system_id,
                           self.device_name,
                           num))
            joblib.dump(flow_instantaneous_scaler_X, 'model/' +
                        '{}_{}_flow_instantaneous_{}_scaler_X'.format(
                            self.system_id,
                            self.device_name,
                            num))
            joblib.dump(flow_instantaneous_scaler_y, 'model/' +
                        '{}_{}_flow_instantaneous_{}_scaler_y'.format(
                            self.system_id,
                            self.device_name,
                            num))
            print('训练完成，保存模型')
        else:
            print('训练完成，不保存模型')

    def flow_instantaneous_predict(self, X):
        '''
        X = data[['freq','delta_pr']]
        Y = data[['flow_instantaneous_2']]
        输入频率和开启的数量，默认为1
        :param X:
        :param num:
        :return:
        '''
        # 取模型
        # X = np.concatenate((X, X * X), axis=1)
        # model = load_model('basic_class/model/' +
        #                    '{}_{}_flow_instantaneous_{}_model.h5'.format(
        #                        self.system_id,
        #                        self.device_name,
        #                        int(num)))
        model = joblib.load('model/' +
                       '{}_{}_flow_instantaneous_model'.format(
                           self.system_id,
                           self.device_name))
        # 读取scaler
        sc_X = joblib.load('model/' +
                           '{}_{}_flow_instantaneous_scaler_X'.format(
                               self.system_id,
                               self.device_name))
        sc_y = joblib.load('model/' +
                           '{}_{}_flow_instantaneous_scaler_y'.format(
                               self.system_id,
                               self.device_name))
        # 对X进行scaler
        X_sc = sc_X.transform(X)
        # 预测y，对y进行预测

        # y_pred = model.predict(X_sc,verbose=0)
        # 调用scaler，输出正确的y
        y_pred = model.predict(X_sc)
        y_pred_sc = sc_y.inverse_transform(y_pred)
        # return y_pred_sc * self.num
        return y_pred_sc
        # 取参数
        # X = X.values.reshape(1, -1)[0]
        # params = np.load(
        #     'model/' +
        #     '{}_{}_flow_instantaneous_params.npy'.format(
        #         self.system_id,
        #         self.device_name
        #     ))
        # c0, c1, c2 = params
        # power = np.array(self.flow_instantaneous_fun(X, c0, c1, c2))
        # return power






if __name__ == "__main__":
    # 2023年5月12日13:15:08
    # 测试通过！！！！！！！终于通过了
    # a = Decdwp_pump_group('3051', 'decdwp_all', 4, 3)
    # X,Y = a.power_get_data(start_time='2023-04-01 00:00:00', end_time='2023-07-07 13:59:00')
    # a.power_train(start_time='2023-07-01 00:00:00', end_time='2023-07-19 13:59:00')
    # X,Y = a.flow_instantaneous_get_data(start_time='2023-05-01 00:00:00', end_time='2023-07-07 23:59:00', num = 3)

    # a.flow_instantaneous_train_test(start_time='2023-07-01 00:00:00', end_time='2023-07-07 13:59:00', num = 2)
    # a.flow_instantaneous_train_test(start_time='2023-05-01 00:00:00', end_time='2023-07-07 23:59:00', num = 3)
    # a.flow_instantaneous_train_test(start_time='2023-05-01 00:00:00', end_time='2023-06-14 23:59:00', num = 4)


    # a.flow_instantaneous_without_train(start_time='2023-05-01 00:00:00', end_time='2023-06-26 00:00:00', num = 2)
    # X,Y = a.flow_instantaneous_without_get_data(start_time='2023-05-01 00:00:00', end_time='2023-08-03 23:59:00', num = 2)
    # import matplotlib.pyplot as plt
    # plt.scatter(X,Y)
    # plt.show()
    # a.flow_instantaneous_without_train(start_time='2023-05-01 00:00:00', end_time='2023-08-03 23:59:00', num = 3)
    # a.flow_instantaneous_without_train(start_time='2023-05-01 00:00:00', end_time='2023-08-03 23:59:00', num = 4)


    # X,Y = a.flow_instantaneous_without_get_data(start_time='2023-03-01 00:00:00', end_time='2023-06-26 00:00:00', num = 4)
    # a.delta_temp_without_train(start_time='2023-03-01 00:00:00', end_time='2023-06-26 00:00:00')
    # a.power_train(start_time='2023-06-01 00:00:00', end_time='2023-06-10 00:00:00')
    # P = a.delta_temp_without_predict(a.delta_temp_without_get_data(
    #     start_time='2023-06-15 00:00:00', end_time='2023-06-16 00:00:00'
    # )[0])
    # Y = a.delta_temp_without_get_data(
    #     start_time='2023-06-15 00:00:00', end_time='2023-06-16 00:00:00'
    # )[1]



    # X,Y = a.flow_instantaneous_without_get_data(start_time='2023-03-01 00:00:00', end_time='2023-05-29 00:00:00', num=2)
    # a.power_train(start_time='2023-03-01 00:00:00', end_time='2023-05-29 00:00:00')
    # print(a.power_predict(a.power_get_data(start_time='2023-05-28 00:00:00', end_time='2023-05-29 00:00:00')[0]))
    # 测试一下
    # a.power_predict(
    #     a.power_get_data(
    #         start_time='2023-05-10 10:00:00',
    #         end_time='2023-05-10 10:10:00')[0])
    # a.flow_instantaneous_train_test(
    #     start_time='2023-05-30 00:00:00',
    #     end_time='2023-06-14 00:00:00',num = 2)
    # a.flow_instantaneous_train_test(
    #     start_time='2023-03-01 00:00:00',
    #     end_time='2023-06-14 00:00:00',num = 3)
    # a.flow_instantaneous_train_test(
    #     start_time='2023-05-01 00:00:00',
    #     end_time='2023-06-14 00:00:00',num = 4)
    # # 测试一下
    # print(a.flow_instantaneous_predict(
        # a.flow_instantaneous_get_data(
        #     start_time='2023-05-01 00:00:00',
        #     end_time='2023-05-30 10:10:00',num =2)[0],num = 2))
    # print(a.flow_instantaneous_get_data(
    #         start_time='2023-05-30 00:00:00',
    #         end_time='2023-05-30 10:10:00',num =2)[1])
    # print(a.flow_instantaneous_predict(
    #     a.flow_instantaneous_get_data(
    #         start_time='2023-05-23 00:00:00',
    #         end_time='2023-05-23 10:10:00',num =3)[0],num = 3))
    # print(a.flow_instantaneous_get_data(
    #         start_time='2023-05-23 00:00:00',
    #         end_time='2023-05-23 10:10:00',num =3)[1])
    # print(a.flow_instantaneous_predict(
    #     a.flow_instantaneous_get_data(
    #         start_time='2023-05-25 00:00:00',
    #         end_time='2023-05-25 20:10:00',num =4)[0],num = 4))
    # print(a.flow_instantaneous_get_data(
    #         start_time='2023-05-25 00:00:00',
    #         end_time='2023-05-25 20:10:00',num =4)[1])
    # X, Y = a.flow_instantaneous_get_data(
    #     start_time='2023-03-04 00:00:00',
    #     end_time='2023-06-05 06:10:00',num = 2)
# np.concatenate()

    import matplotlib.pyplot as plt
    # for i in range(1, 11):
    #     formatted_i = '{:02d}'.format(i)
    #     name = f'decdwp{formatted_i}'
    #     if name == 'decdwp09' or name == 'decdwp10':
    #         a = Decdwp_pump('174', name, 10, 10)
    #         a.power_train(start_time='2023-01-01 00:00:00', end_time='2023-02-28 23:59:59')
    #         X, Y = a.power_get_data(start_time='2023-03-01 00:00:00', end_time='2023-03-31 23:59:59')
    #         P = a.power_predict(X)
    #     else:
    #         a = Decdwp_pump('174', name, 10, 10)
    #         a.power_train(start_time='2023-01-01 00:00:00', end_time='2023-07-31 23:59:59')
    #         X, Y = a.power_get_data(start_time='2023-08-01 00:00:00', end_time='2023-08-27 23:59:59')
    #         P = a.power_predict(X)
    #     mape = mape_sklearn(Y, P)
    #     mae = mean_absolute_error(Y, P)
    #     print('{} power预测的mape是{}  mae是{}'.format(name, mape, mae))








    for i in range(1, 11):
        formatted_i = '{:02d}'.format(i)
        name = f'decdwp{formatted_i}'
        if name == 'decdwp09' or name == 'decdwp10':
            a = Decdwp_pump('174', name, 10, 10)
            a.flow_instantaneous_train_test(start_time='2022-11-01 00:00:00', end_time='2023-02-28 23:59:59')
            X, Y, Z, F = a.flow_instantaneous_get_data(start_time='2023-03-01 00:00:00', end_time='2023-03-31 23:59:59')
            P = a.flow_instantaneous_predict(X)
        else:
            a = Decdwp_pump('174', name, 10, 10)
            a.flow_instantaneous_train_test(start_time='2023-01-01 00:00:00', end_time='2023-07-31 23:59:59')
            X, Y, Z, F = a.flow_instantaneous_get_data(start_time='2023-08-01 00:00:00', end_time='2023-08-27 23:59:59')
            P = a.flow_instantaneous_predict(X)
        mape = mape_sklearn(F, P/Z)
        mae = mean_absolute_error(F, P/Z)
        print('{} power预测的mape是{}  mae是{}'.format(name, mape, mae))



    # plt.scatter(X, Y, label='truth', color='blue')
    # plt.scatter(X, P, label='predicted', color='orange')
    # plt.legend()
    # plt.show()

