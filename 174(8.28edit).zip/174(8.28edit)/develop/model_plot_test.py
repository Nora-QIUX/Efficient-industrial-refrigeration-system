from basic_class.chiller_class import Chiller
from basic_class.pump_class import Decdwp_pump_group
from tools.API import API_class
from sklearn.metrics import mean_absolute_percentage_error as sk_mape
from sklearn.metrics import mean_absolute_error as sk_mae
a = Decdwp_pump_group('3051', 'decdwp_all', 4, 3)
X,Y,Z = a.power_get_data('2023-08-29','2023-08-30')
P = a.power_predict(X,1)
Y = [float(i) for i in Y]
P = [float(i) for i in P]
Z = [i.strftime('%Y-%m-%d %H:%M:00') for i in Z['data_time']]
mape = round(sk_mape(Y,P),3)
mae = round(sk_mae(Y,P),1)
data_1_list = []
data_2_list = []
for true_value,predict_value,data_time in zip(Y,P,Z):
    data_1_list.append({"x":round(true_value,1),"y":round(predict_value,1)})
    data_2_list.append({"x":round(true_value,1),"y":round(predict_value,1),'time':data_time})
res_1_dict = {}
res_1_dict['xUnit'] = 'kW'
res_1_dict['yUnit'] = 'kW'
res_1_dict['data'] = data_1_list

res_2_dict = {}
res_2_dict['unit'] = 'kW'
res_2_dict['data'] = data_2_list


# demo_data
data = {
    "systemId": 174,
    "modelId": "5",
    "modelDesc": "该模型输入为：制冷量，冷凝压力，蒸发压力",
    "modelTrainCycle": "每24小时重新训练",
    "modelAdmin": "钱乔睿",
    "modelStatus": 3,
    "modelMape": str(mape),
    "modelMae": str(mae),
    "modelRealPre": str(res_1_dict),
    "modelShortTermPre": str(res_2_dict)
}
a = API_class()
a.plot_post(data)