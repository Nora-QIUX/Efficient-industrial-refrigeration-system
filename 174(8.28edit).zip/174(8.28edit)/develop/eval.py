import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
from tools.tools import get_heat_data,get_cold_data,get_power_data,conn_000012,get_date
def get_sql(start_time,end_time,table_name):
    '''
    :param start_time:
    :param end_time:
    :param table_name:
    :return:
    '''
    sql = '''
    select * from {} where data_time between '{}' and '{}' '''.format(table_name,start_time,end_time)
    data = pd.read_sql(sql,con=conn_000012)
    return data

def get_chiller(start_time,end_time,table_name):
    '''
    :param start_time:
    :param end_time:
    :param table_name:
    :return:
    '''
    sql = '''
    select
    data_time,device_name,temp_chw_out,
    case when power_active>0 then 1 
    else 0 end as open from {} where data_time between '{}' and '{}' '''.format(table_name,start_time,end_time)
    print(sql)
    data = pd.read_sql(sql,con=conn_000012)
    return data

temp_list = []

start_time = pd.Timestamp(year=2023,month=7,day=21)

for i in range(24):
    delta_time = pd.Timedelta(days=i)
    delta_time_plus_1 = pd.Timedelta(days=i+1) - pd.Timedelta(minutes=1)
    work_time_start = start_time + delta_time
    work_time_end = start_time +delta_time_plus_1
    tmp_df = get_sql(work_time_start,work_time_end,'deth_3051_l1')
    tmp_df['data_time'] =  tmp_df['data_time'].astype('str')
    tmp_date = get_date(work_time_start,work_time_end)
    tmp_df = pd.merge(tmp_date,tmp_df,how = 'left',on = 'data_time')
    dech_tmp_df = get_chiller(work_time_start,work_time_end,'dech_3051_l1')
    chiller_list =  ['dech01','dech02','dech03']
    for num in range(3):
        i = chiller_list[num]
        dech_tmp_i = dech_tmp_df[dech_tmp_df['device_name'] == i]
        dech_tmp_i['data_time'] = dech_tmp_i['data_time'].astype('str')
        dech_tmp_i = pd.merge(tmp_date,dech_tmp_i,how = 'left',on = 'data_time')


        dech_tmp_i['temp_chw_out'] = dech_tmp_i['temp_chw_out'] * dech_tmp_i['open']
        # plt.plot(dech_tmp_i['temp_chw_out'],label = i + '_temp_chw_out')


        dech_tmp_i['open'] = dech_tmp_i['open'].apply(lambda x:x+num if x!=0 else x)
        plt.plot(dech_tmp_i['open'],label = i+'_open')

    plt.plot(tmp_df['temp_outdoor'],label = 'temp')
    plt.plot(tmp_df['temp_wb_outdoor'],label = 'wb_temp')
    plt.legend()
    plt.title(work_time_start.strftime("%Y-%m-%d"))
    plt.show()
    temp_list.append(tmp_df)
d19 = temp_list[-1]
d1 = temp_list[0]
d2 = temp_list[1]
plt.plot(d19['temp_wb_outdoor'],label = '8-12')
plt.plot(d1['temp_wb_outdoor'],label = '7-21')
plt.plot(d2['temp_wb_outdoor'],label = '7-22')
plt.legend()
plt.show()
plt.plot(d19['temp_outdoor'],label = '8-12')
plt.plot(d1['temp_outdoor'],label = '7-21')
plt.plot(d2['temp_outdoor'],label = '7-22')
plt.legend()
plt.show()

con_day = pd.Timestamp(year = 2023, month=7, day= 21)
system_id = '3051'
con_list = []
for i in range(48):
    add_time = pd.Timedelta(minutes= i * 30)
    start_time = (con_day + add_time).strftime('%Y-%m-%d %H:%M:00')
    end_time = (con_day + add_time + pd.Timedelta(minutes = 29)).strftime('%Y-%m-%d %H:%M:00')
    cop = get_cold_data(start_time,end_time,system_id)['all']/get_power_data(start_time,end_time,system_id)['all'] \
        if get_power_data(start_time,end_time,system_id)['all'] != 0 else np.nan
    con_list.append(cop)

test_day = pd.Timestamp(year = 2023, month=8, day= 12)
system_id = '3051'
test_list = []
for i in range(48):
    add_time = pd.Timedelta(minutes= i * 30)
    start_time = (test_day + add_time).strftime('%Y-%m-%d %H:%M:00')
    end_time = (test_day + add_time + pd.Timedelta(minutes = 29)).strftime('%Y-%m-%d %H:%M:00')
    cop = get_cold_data(start_time,end_time,system_id)['all']/get_power_data(start_time,end_time,system_id)['all'] \
        if get_power_data(start_time,end_time,system_id)['all'] != 0 else np.nan
    test_list.append(cop)

plt.plot(con_list,label = '7-21')
plt.plot(test_list,label = '8-12')
plt.legend()
plt.show()


d1['time_cut'] = d1['data_time'].apply(lambda x:pd.to_datetime(x).strftime('%H-0') if pd.to_datetime(x).minute<30 else
                      pd.to_datetime(x).strftime('%H-1'))
d1_mean = d1.groupby(['time_cut']).mean().reset_index()

d19['time_cut'] = d19['data_time'].apply(lambda x:pd.to_datetime(x).strftime('%H-0') if pd.to_datetime(x).minute<30 else
                      pd.to_datetime(x).strftime('%H-1'))
d19_mean = d19.groupby(['time_cut']).mean().reset_index()

import matplotlib.ticker as ticker
x = d19_mean['time_cut']
left_y_1 = d19_mean['temp_wb_outdoor']
left_y_2 = d1_mean['temp_wb_outdoor']
left_y_3 = d19_mean['temp_outdoor']
left_y_4 = d1_mean['temp_outdoor']
right_y_1 = test_list
right_y_2 = con_list

# 创建一个新的图形和轴对象
fig, ax1 = plt.subplots()

# 绘制左侧Y轴数据（蓝色线）
ax1.plot(x, left_y_1, 'g-', label='test_wb_outdoor')
ax1.plot(x, left_y_2, 'g-.', label='con_wb_outdoor')
ax1.plot(x, left_y_3, 'r-', label='test_outdoor')
ax1.plot(x, left_y_4, 'r-.', label='con_outdoor')
ax1.set_xlabel('time')
ax1.set_ylabel('temp', color='green')
ax1.tick_params('y', colors='green')
ax1.set_ylim(5, 34)
# 创建第二个Y轴对象并绘制右侧Y轴数据（红色线）
ax2 = ax1.twinx()
ax2.plot(x, right_y_1, 'b-', label='test_cop')
ax2.plot(x, right_y_2, 'b-.', label='con_cop')
ax2.set_ylabel('cop', color='b')
ax2.set_ylim(4, 6)
ax2.tick_params('y', colors='b')

# 添加图例
lines, labels = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax2.legend(lines + lines2, labels + labels2, loc='lower left')
ax1.tick_params(axis='x', rotation=25)
ax1.xaxis.set_major_locator(ticker.MultipleLocator(base=4))
# plt.title('双Y轴图示例')
plt.show()
# def cop_calculate():

tmp_list = []
for i in [pd.Timestamp(year=2023,month=7,day=11),pd.Timestamp(year=2023,month=8,day=12)]:
    delta_time = pd.Timedelta(days=1)
    delta_time_plus_1 = delta_time- pd.Timedelta(minutes=1)
    work_time_start = i
    work_time_end = work_time_start +delta_time_plus_1
    tmp_df = get_sql(work_time_start, work_time_end, 'decdwpdc_3051_l1')
    tmp_df['data_time'] =  tmp_df['data_time'].astype('str')
    tmp_date = get_date(work_time_start,work_time_end)
    tmp_df = pd.merge(tmp_date,tmp_df,how = 'left',on = 'data_time')
    tmp_df = tmp_df.drop_duplicates(subset=['data_time'],keep = 'first').reset_index(drop = True)
    tmp_list.append(tmp_df)
